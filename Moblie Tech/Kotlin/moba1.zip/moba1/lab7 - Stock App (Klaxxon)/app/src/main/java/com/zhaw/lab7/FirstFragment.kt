package com.zhaw.lab7

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.beust.klaxon.Json
import com.beust.klaxon.Klaxon
import com.zhaw.lab7.databinding.FragmentFirstBinding


class Stock(
    @Json(name = "01. symbol")
    var symbol: String,
    @Json(name = "05. price")
    var price: String
    ) {}

class StockKlaxonBase(@Json(name = "Global Quote") val globalQuote : Stock)

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        //create a request queue
        val requestQueue = Volley.newRequestQueue(requireContext())
        //define a request.
        val request = StringRequest(
            Request.Method.GET, "https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=IBM&apikey=0EQF5I596U8DJ2BT",
            { response ->
                val stockBase = Klaxon().parse<StockKlaxonBase>(response)
                Log.i("ibm", stockBase!!.globalQuote!!.symbol)

                val items = mutableListOf(
                    stockBase!!.globalQuote,
                    Stock("AAPL", "115.69"),
                    Stock("MSFT", "214.36"),
                    Stock("GOOGL", "1519.45"),
                    Stock("CRM", "255.52"))

                val adapter = StockAdapter(
                    items,
                    requireContext());

                binding.listview.adapter = adapter
            },
            {
                //use the porvided VolleyError to display
                //an error message
            })
        //add the call to the request queue
        requestQueue.add(request)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
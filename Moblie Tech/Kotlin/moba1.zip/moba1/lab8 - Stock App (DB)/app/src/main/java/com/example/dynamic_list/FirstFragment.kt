package com.example.dynamic_list

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.beust.klaxon.Klaxon
import com.example.dynamic_list.databinding.FragmentFirstBinding
import com.example.dynamic_list.StockDataViewModel

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null

    val items = mutableListOf(
        Stock("Apple", "AAPL", 115.69),
        Stock("Microsoft", "MSFT", 214.36),
        Stock("Google", "GOOGL", 1519.45),
        Stock("Salesforce", "CRM", 255.52),
        Stock("Facebook", "FB", 260.02),
        Stock("Amazon", "AMZN", 3201.86),
        Stock("eBay", "EBAY", 54.05),
        Stock("Twitter", "TWTR", 45.41),
        Stock("Snapchat", "SNAP", 28.11))

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val model: StockDataViewModel by activityViewModels()

        val adapter = StockAdapter(mutableListOf<Stock>(), requireContext());

        model.stocks.observe(viewLifecycleOwner,
            Observer<MutableList<Stock>> { newVal ->
                adapter?.stocks.clear()
                adapter?.stocks.addAll(newVal)
                adapter?.notifyDataSetChanged()
            }
        )

        context?.let { model.loadStock(it) }


        binding.addBtn.setOnClickListener {
            Log.i("tag", "Button clicked!")
            context?.let { it1 ->
                var requestQueue = Volley.newRequestQueue(requireContext())
                val request = StringRequest(
                    Request.Method.GET, "https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=" + binding.stockTxt.text.toString() +"&apikey=0EQF5I596U8DJ2BT",
                    { response ->
                        val stockBase = Klaxon().parse<StockKlaxonBase>(response)
                        Log.i("ibm", stockBase!!.globalQuote!!.symbol)

                        model.addStock("n/a", binding.stockTxt.text.toString(), stockBase!!.globalQuote!!.price.toDouble(),
                            it1
                        )
                    },
                    {
                        //use the porvided VolleyError to display
                        //an error message
                    })
                //add the call to the request queue
                requestQueue.add(request)

            }
        }

        binding.stockList.adapter = adapter

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
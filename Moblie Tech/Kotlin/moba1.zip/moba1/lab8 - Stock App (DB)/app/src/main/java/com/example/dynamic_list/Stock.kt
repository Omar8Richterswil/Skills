package com.example.dynamic_list

import com.beust.klaxon.Json

class Stock(var name: String, var symbol: String, var value: Double) {
}

class StockKlaxon(
    @Json(name = "01. symbol")
    var symbol: String,
    @Json(name = "05. price")
    var price: String)

class StockKlaxonBase(
    @Json(name = "Global Quote")
    val globalQuote : StockKlaxon)
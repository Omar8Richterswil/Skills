//
//  mobaProjectSwiftApp.swift
//  mobaProjectSwift
//
//  Created by Omar Shakir on 22.05.23.
//

import SwiftUI

@main
struct mobaProjectSwiftApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

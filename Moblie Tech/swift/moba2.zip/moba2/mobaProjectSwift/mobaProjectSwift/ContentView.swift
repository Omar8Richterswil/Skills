//
//  ContentView.swift
//  iTunes
//
//  Created by Omar Shakir on 21.05.23.
//

import SwiftUI
import Foundation

struct ContentView: View {
    @State var from : String = "Zurich"
    @State var to : String = "Zug"
    var body: some View {
        NavigationView {
            VStack {
                Text("From:")
                TextField("From", text: $from, onEditingChanged: {t in},
                          onCommit: {})
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding().accessibility(hint: Text("Search itunes album"))
                Text("To:")
                TextField("To", text: $to, onEditingChanged: {t in},
                          onCommit: {})
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding().accessibility(hint: Text("Search itunes album"))
                
                NavigationLink(destination: SearchResultView(fromParam: self.from, toParam: self.to))
                {Text("Search")}
              }
              .navigationTitle("Transportation Search App")
        }
            .navigationViewStyle(
                StackNavigationViewStyle()
            )
    }
    
}

struct SearchResultView : View {
    var fromParam : String
    var toParam : String
    
    @State var transportationData : Transportation = Transportation(connections: [ConnectionEntry]())
    
    var body: some View {
        List(transportationData.connections) { entry in
            VStack {
                HStack {
                    Text(entry.from.hourminuteDeparture).padding()
                    Text(entry.from.station.name)
                    Spacer()
                    Text(entry.duration)
                }
                HStack{
                    Text(entry.to.hourminuteArrival).padding()
                    Text(entry.to.station.name)
                    Spacer()
                    NavigationLink(destination: DetailView(entry: entry, stationList: entry.sections[0].journey!.passList)){}
                }
            }
        }
        .refreshable{
            Task {
                await transportationData = loadJson()
                print("Data reloaded")
            }
        }
        .onAppear(perform: {
            Task {
                 await transportationData = loadJson()
            }
        })
    }

    func loadJson() async -> Transportation {
        do {
            //read the file. Note that you can also use a url later
            let data = try await download()
            //create a data instance
            // let data = try Data(contentsOf: file!)
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            //and decode it to Person
            return try decoder.decode(Transportation.self, from: data)
        } catch {
            fatalError("Couldn't load file from main bundle:\n\(error)")
        }
    }
    
    func download() async throws -> Data {
        let url = URL(string: "https://transport.opendata.ch/v1/connections?from=" + self.fromParam + "&to=" + self.toParam)
        let urlRequest = URLRequest(url: url!)
        let (data, _) =
            try await URLSession.shared.data(for: urlRequest)
        //optional: check response
        return data
    }
}

struct DetailView : View {
    var entry : ConnectionEntry
    
    var stationList : [passListEntry]
    
    var body: some View {
            VStack {
                HStack {
                    Text("Departure Time:").padding()
                    Spacer()
                    Text(entry.from.hourminuteDeparture).padding()
                }
                
                HStack {
                    Text("Departure Platform:").padding()
                    Spacer()
                    Text(entry.from.platform).padding()
                }
                
                HStack {
                    Text("Arrival Time:").padding()
                    Spacer()
                    Text(entry.to.hourminuteArrival).padding()
                }
                
                HStack {
                    Text("Arrival Platform:").padding()
                    Spacer()
                    Text(entry.to.platform).padding()
                }
                
                HStack {
                    Text("Train Number:").padding()
                    Spacer()
                    Text(entry.sections[0].journey!.category + entry.sections[0].journey!.number).padding()
                }
                
                HStack {
                    Text("Train Operator:").padding()
                    Spacer()
                    Text(entry.sections[0].journey!.operator).padding()
                }

                StationListView(stationList: self.stationList)
            }
    }
}

struct StationListView : View {
    var stationList : [passListEntry]
    
    var body: some View {
        List(stationList) { entry in
            HStack {
                Text("Station:").padding()
                Spacer()
                Text(entry.station.name).padding()
            }
        }
    }
}

struct Transportation : Decodable {
    var connections : [ConnectionEntry]
}

struct ConnectionEntry : Decodable, Identifiable {
    var duration : String
    var from : StationEntry
    var to : StationEntry
    var sections : [SectionEntry]
    
    var id : String {
        get {
            return duration
        }
    }
}

struct SectionEntry : Decodable, Identifiable {
    var journey : journeyEntry?
    
    var id : String {
        get {
            return UUID().uuidString
        }
    }
}

struct journeyEntry : Decodable, Identifiable {
    var number : String
    var category : String
    var `operator` : String
    var passList : [passListEntry]
    
    var id : String {
        get {
            return number
        }
    }
}

struct passListEntry : Decodable, Identifiable {
    var station : StationDetailEntry
    var platform : String?
    
    var id : String {
        get {
            return UUID().uuidString
        }
    }
}

struct StationEntry : Decodable, Identifiable {
    var station : StationDetailEntry
    var arrival : Date?
    var departure : Date?
    var platform : String
    
    var id : String {
        get {
            return platform
        }
    }
    
    var hourminuteDeparture : String {
        get {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "HH:mm"
            return dateFormatter.string(from: departure!)
        }
    }
    
    var hourminuteArrival : String {
        get {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "HH:mm"
            return dateFormatter.string(from: arrival!)
        }
    }
}

struct StationDetailEntry : Decodable, Identifiable {
    var name : String
    
    var id : String {
        get {
            return UUID().uuidString
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

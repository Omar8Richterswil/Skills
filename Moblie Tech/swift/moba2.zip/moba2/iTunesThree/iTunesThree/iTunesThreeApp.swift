//
//  iTunesThreeApp.swift
//  iTunesThree
//



import SwiftUI

@main
struct iTunesThreeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

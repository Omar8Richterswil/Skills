import SwiftUI

struct Album: Decodable {
    var results: [AlbumEntry]
}

struct AlbumEntry: Identifiable, Decodable {
    var collectionId: Int
    var artistName: String
    var collectionName: String
    var artworkUrl100: String
    var id: Int{
        get {
            return collectionId
        }
    }
}

struct Song: Decodable {
    var results: [SongEntry]
}

struct SongEntry: Identifiable, Decodable {
    var wrapperType: String!
    var artistId: Int!
    var trackId: Int?
    var trackName: String?
    var collectionName: String?
    var artworkUrl60: String?
    var artworkUrl100: String?
    var previewUrl: String?
    var artistName: String?
    var trackViewUrl: String?
    var collectionId: Int!
    var trackCount: Int?
    var releaseDate: String?
    var primaryGenreName: String?
    var id: String{
        get {
            return String(artistId) + trackName!
        }
    }
}

struct DetailView : View {
    
    @State var detailedData : Song = Song(results: [SongEntry]())
    @State var collectionId : Int = 5128073
    @State var imageUrl : String
    @State var title : String
    
    
    var body : some View {
        //data.results.remove(at: 0)
        VStack{
            Text(title)
            AsyncImage(url: URL(string: imageUrl))
        }
        List(detailedData.results) { entry in
            Text(String(entry.trackName ?? "missing data"))
        }.listStyle(PlainListStyle()).onAppear(perform: {
            Task {
                await detailedData = loadJSONSong()
                detailedData.results.remove(at: 0)
            }
        })
    }
    
    func downloadSong() async throws -> Data {
        let url = URL(string: "https://itunes.apple.com/lookup?id="+String(collectionId)+"&entity=song")
        let urlRequest = URLRequest(url: url!)
        let (data, _) = try await URLSession.shared.data(for:urlRequest)
        return data
    }
    
    func loadJSONSong() async -> Song {
        do {
            let data = try await downloadSong()
            let decoder = JSONDecoder()
            
            return try decoder.decode(Song.self, from: data)
        } catch {
            //fatalError("Couldnt load file from server\n\(error)")
            fatalError("aj")
        }
    }
}


struct ContentView: View {
    @State var data : Album = Album(results: [AlbumEntry]())
    
    @State var name : String = "thriller"
        
    var body: some View {
        
        TextField("Name", text: $name, onEditingChanged: {t in},
        onCommit: {
            Task {
                await data = loadJSON()
            }
        })
        .textFieldStyle(RoundedBorderTextFieldStyle())
        .padding().accessibility(hint: Text("Name"))
        
        NavigationView {
            List(data.results) { entry in
                HStack{
                    //Image(entry.artworkUrl100)
                    AsyncImage(url: URL(string: entry.artworkUrl100))
                    VStack {
                        Text(entry.collectionName).bold().frame(maxWidth: .infinity, alignment:.leading)
                        Text(entry.artistName).frame(maxWidth: .infinity, alignment:.leading)
                    }
                    NavigationLink(entry.artistName, destination: DetailView(collectionId: entry.collectionId, imageUrl: entry.artworkUrl100, title: entry.artistName))
                }
            }.refreshable {
                Task {
                    await data = loadJSON()
                }
            }.onAppear(perform: {
                Task {
                    await data = loadJSON()
                }
            })
            
        }
        


    }
    
    
    func download() async throws -> Data {
        let url = URL(string: "https://itunes.apple.com/search?term="+name.filter{!$0.isWhitespace}+"&entity=album")
        let urlRequest = URLRequest(url: url!)
        let (data, _) = try await URLSession.shared.data(for:urlRequest)
        return data
    }
    
    func loadJSON() async -> Album {
        do {
            let data = try await download()
            let decoder = JSONDecoder()
            return try decoder.decode(Album.self, from: data)
        } catch {
            fatalError("Couldnt load file from server")
        }
    }
    

    
}

package gruppe03.gamma.Projekt2.MEDMobile;

import gruppe03.gamma.Projekt2.MEDMobile.Model.DateUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.GregorianCalendar;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class DateUtilTest {
	
	private DateUtil dateUtilUnderTest;
	
	@BeforeEach
	void setUp() {
		dateUtilUnderTest = new DateUtil();
	}
	
	
	@Test
	void testDaysToMillisec() {
		assertEquals(0L, DateUtil.daysToMillisec(0L));
	}
	
	@Test
	void testDaysBetweenDates() {
		assertEquals(0L, DateUtil.daysBetweenDates(new GregorianCalendar(2019, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2019, Calendar.JANUARY, 1).getTime()));
	}
	
	@Test
	void testAddDaysToDate() {
		assertEquals(new GregorianCalendar(2019, Calendar.JANUARY, 1).getTime(), DateUtil.addDaysToDate(new GregorianCalendar(2019, Calendar.JANUARY, 1).getTime(), 0));
	}
	
	@Test
	void testGetDDMMYYYY() {
		assertEquals("01-01-2019", DateUtil.getDDMMYYYY(new GregorianCalendar(2019, Calendar.JANUARY, 1).getTime()));
	}
	
	@Test
	void testGetMondayDateofThatDay() {
		assertEquals(new GregorianCalendar(2018, Calendar.DECEMBER, 30).getTime(), DateUtil.getMondayDateofThatDay(new GregorianCalendar(2019, Calendar.JANUARY, 1).getTime()));
	}


}

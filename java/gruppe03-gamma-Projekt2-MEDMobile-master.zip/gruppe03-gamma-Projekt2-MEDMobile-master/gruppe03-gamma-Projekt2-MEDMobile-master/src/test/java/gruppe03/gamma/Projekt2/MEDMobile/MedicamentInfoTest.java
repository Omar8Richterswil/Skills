package gruppe03.gamma.Projekt2.MEDMobile;

import gruppe03.gamma.Projekt2.MEDMobile.Model.Medicament;
import gruppe03.gamma.Projekt2.MEDMobile.Model.MedicamentInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MedicamentInfoTest {
    Medicament testMedicament;
    String testMediName = "Test";
    MedicalUtil.amountType testAmountType = MedicalUtil.amountType.MG;
    MedicalUtil.mediType testMediType = MedicalUtil.mediType.TABLET;
    int testDose = 500;
    AlarmFrequency testAlarmFrequency = AlarmFrequency.Dailly;

    @Spy
    MedicamentInfo mockMedicamentInfo;

    @BeforeEach
    void setUp() {
        testMedicament = new Medicament(testMediName,testMediType,testAmountType,testDose,testAlarmFrequency);
        mockMedicamentInfo= new MedicamentInfo();
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void listHasAlreadyFourMedicaments(){
        assertEquals(4,mockMedicamentInfo.getMedicamentList().size());
    }
    @Test
    void addMedicament() {
        assertEquals(4,mockMedicamentInfo.getMedicamentList().size());
        mockMedicamentInfo.addMedicament(testMedicament);
        assertEquals(5,mockMedicamentInfo.getMedicamentList().size());
        verify(mockMedicamentInfo,times(1)).addMedicament(testMedicament);
        verify(mockMedicamentInfo,times(2)).getMedicamentList();

    }

    @Test
    void validateEntryTrue() {
        assertEquals(true,mockMedicamentInfo.validateEntry(testMedicament));
        verify(mockMedicamentInfo,times(1)).validateEntry(testMedicament);
    }

    @Test
    void validateEntryFalse(){
        mockMedicamentInfo.addMedicament(testMedicament);
        assertEquals(false,mockMedicamentInfo.validateEntry(testMedicament));
        verify(mockMedicamentInfo, times(1)).validateEntry(testMedicament);


    }

    @Test
    void getMedicamentfromNameAndDose() {
        mockMedicamentInfo.addMedicament(testMedicament);
        assertEquals(testMedicament, mockMedicamentInfo.getMedicamentfromNameAndDose("Test",500));
        verify(mockMedicamentInfo, times(1)).getMedicamentfromNameAndDose("Test",500);
    }
    @Test
    void getMedicamentfromNameAndDoseResultsInNUll() {
        assertEquals(null, mockMedicamentInfo.getMedicamentfromNameAndDose("Test",500));
        verify(mockMedicamentInfo, times(1)).getMedicamentfromNameAndDose("Test",500);
    }

}
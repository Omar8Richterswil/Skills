package gruppe03.gamma.Projekt2.MEDMobile;

import gruppe03.gamma.Projekt2.MEDMobile.Controller.MedicamentInfoController;
import gruppe03.gamma.Projekt2.MEDMobile.Model.Medicament;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MedicamentInfoControllerTest {
   // MedicamentInfoController medicamentInfoController= new MedicamentInfoController();

    @Spy
    MedicamentInfoController medicamentInfoController= new MedicamentInfoController();
    @Mock
    Medicament medicament;
    @BeforeEach
    void setUp(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void addMedicament() {
    medicamentInfoController.addMedicament(medicament.getName(),medicament.getMediType(),medicament.getAmountType(),medicament.getDose(),medicament.getAlarmFrequency());
    assertEquals(5,medicamentInfoController.getMedicamentList().size());
    verify(medicamentInfoController,times (1)).addMedicament(medicament.getName(),medicament.getMediType(),medicament.getAmountType(),medicament.getDose(),medicament.getAlarmFrequency());

    }

    @Test
    void addMedicamentWhichAlreadyExists(){
        medicamentInfoController.addMedicament(medicament.getName(),medicament.getMediType(),medicament.getAmountType(),medicament.getDose(),medicament.getAlarmFrequency());
        medicamentInfoController.addMedicament(medicament.getName(),medicament.getMediType(),medicament.getAmountType(),medicament.getDose(),medicament.getAlarmFrequency());
        assertEquals(5,medicamentInfoController.getMedicamentList().size());
        verify(medicamentInfoController,times (2)).addMedicament(medicament.getName(),medicament.getMediType(),medicament.getAmountType(),medicament.getDose(),medicament.getAlarmFrequency());
    }

    @Test
    void getMedicamentByNameAndDose() {
        when(medicament.getDose()).thenReturn(500);
        when(medicament.getName()).thenReturn("test");
        medicamentInfoController.addMedicament(medicament.getName(),medicament.getMediType(),medicament.getAmountType(),medicament.getDose(),medicament.getAlarmFrequency());
        assertEquals(medicament.getName(),medicamentInfoController.getMedicamentByNameAndDose(medicament.getName(),medicament.getDose()).getName());
        verify(medicamentInfoController, times(1)).getMedicamentByNameAndDose(medicament.getName(),medicament.getDose());
    }

    @Test
    void getMedicamentByNameAndDoseWithNull() {
        
        assertEquals(null,medicamentInfoController.getMedicamentByNameAndDose(medicament.getName(),medicament.getDose()));
        verify(medicamentInfoController, times(1)).getMedicamentByNameAndDose(medicament.getName(),medicament.getDose());

    }
}
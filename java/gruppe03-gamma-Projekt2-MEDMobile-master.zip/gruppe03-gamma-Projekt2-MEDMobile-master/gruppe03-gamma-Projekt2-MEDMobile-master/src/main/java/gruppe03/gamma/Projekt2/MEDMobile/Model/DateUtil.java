package gruppe03.gamma.Projekt2.MEDMobile.Model;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static java.sql.Date.valueOf;
import static java.util.Date.*;


public class DateUtil {
    /**
     * Get days in Milliseconds
     * @param days
     * @return milliseconds
     */
    public static long daysToMillisec (long days) {
        long milliseconds=days*1000*60*60*24;
        return milliseconds;

    }

    /**
     * Get the amount of days between two dates
     * @param date1
     * @param date2
     * @return daysBetweenDates
     */
    public static long daysBetweenDates(Date date1, Date date2) {
        long diff = Math.abs(date1.getTime() - date2.getTime());
        return diff / daysToMillisec(1);
    }

    /**
     * Get date with amount of days added to the date passed as an argument
     * @param date
     * @param days
     * @return newDate
     */
    public static Date addDaysToDate(Date date, int days) {
        return new Date(date.getTime() + daysToMillisec(days));
    }

    /**
     * Get a string describing the date in dd-MM-yyyy
     * @param date
     * @return ddMMyyyyDateString
     */
    public static String getDDMMYYYY(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        return dateFormat.format(date);
    }

    /**
     * Gets the Date of the Monday of any Date
     * @param startDate
     * @return Date
     */
    public static Date getMondayDateofThatDay(Date startDate) {
        Date mondayDate;
        int day;

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        day= calendar.get(Calendar.DAY_OF_WEEK);
        if (day==0) {
            day=7;
        }
        day=1-day;
        mondayDate= addDaysToDate(startDate, day);

        return mondayDate;
    }

    public static boolean getDDMMYYYY(String text) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        return Boolean.parseBoolean(dateFormat.format(text));
    }

    public static Date parse(String text) {
        return valueOf(text);
    }

    @Override
    public String toString() {
        return "DateUtil{}";
    }
}

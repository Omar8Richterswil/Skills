package gruppe03.gamma.Projekt2.MEDMobile;

import gruppe03.gamma.Projekt2.MEDMobile.Model.DateUtil;


/**
 *
 */
public class TakeDose {

    private final int id;
    private final DateUtil time;
    private int shift;
    private boolean taken;

    public TakeDose(int id, DateUtil time, boolean taken) {
        this.id = id;
        this.time = time;
        this.shift = shift;
        this.taken = taken;
    }

    public boolean isTaken() {
        return taken;
    }

    public void setTaken(boolean taken) {
        this.taken = taken;
    }

    public DateUtil getTime() {
        return time;
    }


}

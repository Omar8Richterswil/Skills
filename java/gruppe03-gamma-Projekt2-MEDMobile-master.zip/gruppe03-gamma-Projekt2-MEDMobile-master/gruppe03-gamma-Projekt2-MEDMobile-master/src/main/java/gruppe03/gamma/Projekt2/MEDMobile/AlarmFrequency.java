package gruppe03.gamma.Projekt2.MEDMobile;


import java.util.stream.Stream;

/**
 * Alarm frequency to see how may dose should teke in a day
 */
public enum AlarmFrequency {
    ThreeTimeinDay(8),TowTimeinDay(12),FourTimeinDay(6),
    Dailly(24),OnceEvryTowDays(28);

    private int hour;

    AlarmFrequency(int hours) {
        this.hour = hours;
    }

    public int getHour() {
        return hour;
    }

    /**
     * the alarm frequency depend on the the hour
     * @param hour
     * @return
     */
    public static AlarmFrequency hourFrequency(int hour) {
        return Stream.of(AlarmFrequency.values())
                .filter(f -> f.getHour() == hour)
                .findFirst()
                .orElseThrow(IllegalArgumentException::new);
    }
}

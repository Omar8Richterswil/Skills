package gruppe03.gamma.Projekt2.MEDMobile.View;

import gruppe03.gamma.Projekt2.MEDMobile.Model.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

/**
 * this class is the controller to add new user
 */
public class AddNewUser {


    Stage dialogestage;
    @FXML
    private TextField firstNameField;
    @FXML
    private TextField lastNameField;
    @FXML
    private TextField InsuranceNumber;
    @FXML
    private TextField PasswordField;
    @FXML
    private TextField UserNameField;
    @FXML
    private TextField AgeField;
    @FXML
    private TextField HeightField;
    @FXML
    private TextField WeightField;
    @FXML
    private RadioButton male;
    @FXML
    private RadioButton female;
    private char gender;
    @FXML
    private CheckBox isNurse;
    @FXML
    private Button CancelButton;
    @FXML
    private Button OkButton;
    private User user = new User();
    private boolean OkClicke = false;

    /**
     * set the user
     *
     * @param user
     */

    public void setUser(User user) {
        this.user = user;
        firstNameField.setText(user.getLastname());
        lastNameField.setText(user.getFirstname());
        InsuranceNumber.setText(user.getInsuranceNumber());
        PasswordField.setText(user.getPassword());
        UserNameField.setText(user.getUsername());

        HeightField.setText(Integer.toString(user.getHeightCM()));
        WeightField.setText(Integer.toString(user.getWeightKg()));

    }

    public boolean isOkClicked() {
        return OkClicke;
    }

    /**
     * Handle ok button
     */
    @FXML
    private void handleOk() {
        if (isInputValid()) {
            user.setFirstname(firstNameField.getText());
            user.setUsername(lastNameField.getText());

            user.setUsername(PasswordField.getText());
            user.setPassword(UserNameField.getText());

            user.setAge(Integer.parseInt(AgeField.getText()));
            HeightField.setText(Integer.toString(user.getHeightCM()));
            WeightField.setText(Integer.toString(user.getWeightKg()));

            if (isNurse.isSelected()) {
                user.isNurse();
            }

            if (male.isSelected()) {
                gender = 'm';
            }
            if (female.isSelected()) {
                gender = 'f';
            }

            OkClicke = true;
            Stage stage = (Stage) OkButton.getScene().getWindow();
            stage.close();

            Parent root;
            try {
                URL fxmlResource = ClassLoader.getSystemResource("MainViewPatient.fxml");
                root = FXMLLoader.load(fxmlResource);
                Stage newstage = new Stage();
                newstage.setTitle("main");
                newstage.setScene(new Scene(root, 1000, 700));
                newstage.show();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * handle cancel button
     */

    @FXML
    private void handleCancel() {

        Stage stage = (Stage) CancelButton.getScene().getWindow();

        stage.close();
    }

    /**
     * cheake if the input in valid format
     *
     * @return
     */
    private boolean isInputValid() {

        String errorMessage = "";

        if (firstNameField.getText() == null || firstNameField.getText().length() == 0) {
            errorMessage += "No valid first name!\n";
        }
        if (lastNameField.getText() == null || lastNameField.getText().length() == 0) {
            errorMessage += "No valid last name!\n";
        }
        if (InsuranceNumber.getText() == null || InsuranceNumber.getText().length() == 0) {
            errorMessage += "No valid insurance Number\n";
        }

        if (PasswordField.getText() == null || PasswordField.getText().length() == 0) {
            errorMessage += "No valid Password!\n";
        }
        if (UserNameField.getText() == null || UserNameField.getText().length() == 0) {
            errorMessage += "No valid Username!\n";
        }


        if (errorMessage.length() == 0) {
            return true;
        } else {
            {
                // Show the error message.
                Alert alert = new Alert(AlertType.ERROR);
                alert.initOwner(dialogestage);
                alert.setTitle("Invalid Fields");
                alert.setHeaderText("Please correct invalid fields");
                alert.setContentText(errorMessage);

                alert.showAndWait();

            }

        }
        return false;
    }
}

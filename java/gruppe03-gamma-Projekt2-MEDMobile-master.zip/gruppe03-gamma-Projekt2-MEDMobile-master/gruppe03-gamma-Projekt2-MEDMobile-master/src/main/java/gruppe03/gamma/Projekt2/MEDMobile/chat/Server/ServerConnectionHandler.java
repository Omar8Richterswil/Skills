package gruppe03.gamma.Projekt2.MEDMobile.chat.Server;


import gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol.ChatConfig;
import gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol.ChatProtocolException;
import gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol.ConnectionHandler;
import gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol.NetworkHandler;

import java.util.HashMap;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

import static gruppe03.gamma.Projekt2.MEDMobile.chat.Server.ServerConnectionHandler.State.CONNECTED;
import static gruppe03.gamma.Projekt2.MEDMobile.chat.Server.ServerConnectionHandler.State.DISCONNECTED;


public class ServerConnectionHandler extends ConnectionHandler {
    private static final AtomicInteger connectionCounter = new AtomicInteger(0);
    private final int connectionId = connectionCounter.incrementAndGet();
    private final NetworkHandler.NetworkConnection<String> connection;
    private final HashMap<String, ServerConnectionHandler> connectionRegistry;
    private static final Logger logger = Logger.getLogger(ServerConnectionHandler.class.getCanonicalName());
    private String userName = "Anonymous-" + connectionId;
    private State state = State.NEW;

    @Override
    public void run() {
        startReceiving();
    }

    enum State {NEW, CONNECTED, DISCONNECTED}


    public ServerConnectionHandler(NetworkHandler.NetworkConnection<String> connection,
                                   HashMap<String, ServerConnectionHandler> registry) {
        super(connection);
        Objects.requireNonNull(connection, "Connection must not be null");
        Objects.requireNonNull(registry, "Registry must not be null");
        this.connection = connection;
        this.connectionRegistry = registry;
    }


    public String getUserName() {
        return this.userName;
    }

    /**
     * startReceiving is used in run() method,  starts connectionHandler
     */
    public void startReceiving() {
        logger.info("Starting Connection Handler for " + userName);
        Exception exception = startReceivingExp();
        if(exception != null){
            connectionRegistry.remove(userName);
            logger.info("Unregistered because client connection terminated: " + userName + " " + exception.getMessage());
        }
        logger.info("Stopping Connection Handler for " + userName);
    }

    @Override
    protected void getConnected(ChatConfig chatConfig) throws ChatProtocolException {
        if (this.state != State.NEW) {
            throw new ChatProtocolException("Illegal state for connect request: " + state);
        }
        String sender = chatConfig.getSender();
        if (sender == null || sender.isBlank()) {
            sender = this.userName;
        }
        if (connectionRegistry.containsKey(sender)) {
            throw new ChatProtocolException("User name already taken: " + chatConfig.getSender());
        }
        this.userName = sender;
        connectionRegistry.put(userName, this);
        sendData(new ChatConfig(USER_NONE, userName, ChatConfig.Type.CONFIRM, "Registration successfull for " + userName));
        this.state = CONNECTED;
    }

    @Override
    protected void getConfirmed(ChatConfig chatConfig){
        logger.info("Confirm from client");
    }

    @Override
    protected void getDisconnected(ChatConfig chatConfig) throws ChatProtocolException {
        if (state == DISCONNECTED)
            throw new ChatProtocolException("Illegal state for disconnect request: " + state);
        if (state == CONNECTED) {
            connectionRegistry.remove(this.userName);
        }
        sendData(new ChatConfig(USER_NONE, userName, ChatConfig.Type.CONFIRM, "Confirm disconnect of " + userName));
        this.state = DISCONNECTED;
        this.stopReceiving();
    }

    @Override
    protected void getMessage(ChatConfig chatConfig) throws ChatProtocolException {
        if (state != CONNECTED)
            throw new ChatProtocolException("Illegal state for message request: " + state);
        if (USER_ALL.equals(chatConfig.getReceiver())) {
            for (ServerConnectionHandler handler : connectionRegistry.values()) {
                handler.sendData(chatConfig);
            }
        } else {
            ServerConnectionHandler handler = connectionRegistry.get(chatConfig.getReceiver());
            ServerConnectionHandler handlerSender = connectionRegistry.get(chatConfig.getSender());
            if (handler != null && handlerSender != null) {
                handler.sendData(chatConfig);
                handlerSender.sendData(chatConfig);
            } else {
                this.sendData(new ChatConfig(USER_NONE, userName, ChatConfig.Type.ERROR, "Unknown User: " + chatConfig.getReceiver()));
            }
        }
    }

    @Override
    protected void getError(ChatConfig chatConfig){
        logger.warning("error notification from the client (" + chatConfig.getSender() + "): " + chatConfig.getPayload());
    }



}

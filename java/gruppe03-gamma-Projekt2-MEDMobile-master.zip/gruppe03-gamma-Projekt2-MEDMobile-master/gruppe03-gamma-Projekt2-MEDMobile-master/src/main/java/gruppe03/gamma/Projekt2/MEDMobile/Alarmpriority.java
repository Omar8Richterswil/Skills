package gruppe03.gamma.Projekt2.MEDMobile;


/**
 * AlarmPriority to show how important is to give the dose in time
 */
public enum Alarmpriority
{
    NORMAL(0),
    IMPORTANT(1),
    CRITICAL(2);

    // region constants

    private static final String ERROR_CANNOT_CONVERT_INT_TO_ALARM_SEVERITY = "Cannot convert int to AlarmSeverity";

    private final int value;


    Alarmpriority(int value)
    {
        this.value = value;
    }

    public int getValue()
    {
        return value;
    }

    /**
     * the value of priority normal , impotant , critical
     * @param value
     * @return
     * @throws StringTimeException
     */
    public static Alarmpriority fromInt(int value) throws StringTimeException
    {
        switch (value)
        {
            case 0:
                return Alarmpriority.NORMAL;

            case 1:
                return Alarmpriority.IMPORTANT;

            case 2:
                return Alarmpriority.CRITICAL;

            default:
                throw new StringTimeException("ERROR");
        }
    }
}
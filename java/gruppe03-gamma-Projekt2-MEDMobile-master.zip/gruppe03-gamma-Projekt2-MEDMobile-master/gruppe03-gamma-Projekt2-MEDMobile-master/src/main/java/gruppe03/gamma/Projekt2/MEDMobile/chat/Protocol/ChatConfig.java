package gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol;

import java.io.Serializable;
import java.util.Scanner;


/**
 * ChatConfig was a part from processData in handler classes
 * its send message and implements Serializable (https://www.baeldung.com/java-serialization)
 */

public class ChatConfig implements Serializable {

    private String sender;
    private String receiver;
    private Type type;
    private String payload;



    public enum Type {
        CONNECT, CONFIRM, DISCONNECT, MESSAGE, ERROR
    }

    public ChatConfig(String sender, String receiver, Type type, String payload) {
        this.sender = sender;
        this.receiver = receiver;
        this.type = type;
        this.payload = payload;
    }

    public String getSender() {
        return sender;
    }

    public String getReceiver() {
        return receiver;
    }

    public Type getType() {
        return type;
    }

    public String getPayload() {
        return payload;
    }



    /**
     dataString code was part from processData method
     */
    public static ChatConfig dataString(String string) throws ChatProtocolException {


        try (Scanner scanner = new Scanner(string)) {
            String sender;
            String receiver;
            Type type;
            // should intilize with null which is space
            String payload = "";
            if (scanner.hasNextLine()) {
                sender = scanner.nextLine();
            } else {
                throw new ChatProtocolException("No Sender found");
            }
            if (scanner.hasNextLine()) {
                receiver = scanner.nextLine();
            } else {
                throw new ChatProtocolException("No Receiver found");
            }
            if (scanner.hasNextLine()) {
                type = Type.valueOf(scanner.nextLine());
            } else {
                throw new ChatProtocolException("No Type found");
            }
            if (scanner.hasNextLine()) {
                payload = scanner.nextLine();
            }
            return new ChatConfig(sender, receiver, type, payload);
        }
    }

    @Override
    public String toString() {
        String chat = System.lineSeparator();
        return sender + chat + receiver + chat + type + chat + payload + chat;
    }
}
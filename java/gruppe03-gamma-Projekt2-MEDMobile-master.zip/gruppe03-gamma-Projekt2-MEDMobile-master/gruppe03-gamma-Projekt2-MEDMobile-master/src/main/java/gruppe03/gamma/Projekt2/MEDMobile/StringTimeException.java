package gruppe03.gamma.Projekt2.MEDMobile;

public class StringTimeException extends Exception {

    public StringTimeException(String s) {
        // Call constructor of parent Exception
        super(s);
    }
}

package gruppe03.gamma.Projekt2.MEDMobile;

/**
 * Class Medical Util has Enums that are used for the Medicaments
 */
public class MedicalUtil {

    /**
     * Different medicament types
     */
    public enum mediType{
        TABLET,
        DROPS,
        SYRUP,
        CREAM
    }

    /**
     * Different amount types
     */
    public enum amountType{
        MG,
        DROPS,
        ML
    }
}

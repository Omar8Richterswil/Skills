package gruppe03.gamma.Projekt2.MEDMobile.chat.Client.src.main.java.controller;

import gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol.ChatProtocolException;
import gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol.NetworkHandler;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.WindowEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static gruppe03.gamma.Projekt2.MEDMobile.chat.Client.src.main.java.controller.ClientConnectionHandler.State.*;


/**
 * ChatWindowController is the controller class for the fxml file in the resources folder.
 * it controls the textfields , textarea and buttons as well as  it can start the gui and end it
 *
 */
public class ChatWindowController {


    // logger with small letter to avoid Logger
    private static final Logger logger = Logger.getLogger(ChatWindowController.class.getCanonicalName());
    private final Pattern messagePattern = Pattern.compile("^(?:@(\\w*))?\\s*(.*)$");
    private ClientConnectionHandler connectionHandler;
    private WindowCloseHandler windowCloseHandler = new WindowCloseHandler();

    @FXML
    private Pane rootPane;
    @FXML
    private TextField serverAddressField;
    @FXML
    private TextField serverPortField;
    @FXML
    private TextField userNameField;
    @FXML
    private TextField messageField;
    @FXML
    private TextArea messageArea;
    @FXML
    private Button connectButton;
    @FXML
    private Button sendButton;


    public ChatWindowController() {
        logger.setLevel(Level.ALL);
    }

    /**
     * initializing GUI with the DEFAULT_ADDRESS.
     */

    @FXML
    public void initialize() throws ChatProtocolException {
        serverAddressField.setText(NetworkHandler.DEFAULT_ADDRESS.getCanonicalHostName());
        serverPortField.setText(String.valueOf(NetworkHandler.DEFAULT_PORT));
        stateChanged(NEW);
    }

    /**
     * if the application Closes the state will be set to DISCONNECTED
     */
    private void applicationClose() {
        connectionHandler.setState(DISCONNECTED);
    }

    /**
     * Connects when its not connected, disconnects otherwise
     */
    @FXML
    private void toggleConnection() throws ChatProtocolException {
        if (connectionHandler == null || connectionHandler.getState() != CONNECTED) {
            connect();
        } else {
            disconnect();
        }
    }

    /**
     * is used from toggleConnection(), starts ConnectionHandler and uses connect() from connectionHandler
     */
    private void connect() {

        try {
            startConnectionHandler();
            connectionHandler.connect();

        } catch (IOException | ChatProtocolException e) {
            writeError(e.getMessage());
        }
    }

    /**
     * disconnects if there is a connectionhandler
     */
    private void disconnect() {
        if (connectionHandler == null) {
            writeError("No connection handler");
            return;
        }
        try {
            connectionHandler.disconnect();
        } catch (ChatProtocolException e) {
            writeError(e.getMessage());
        }
    }

    /**
     * gets message from messageField and gives it to connectionHandler, sets Field after sending to blank
     */
    @FXML
    private void message() throws ChatProtocolException {
        if (connectionHandler == null) {
            writeError("No connection handler, you should connect first");
            return;
        }
        String messageString = messageField.getText().strip();

        Matcher matcher = messagePattern.matcher(messageString);

        if (matcher.find()) {
            String receiver = matcher.group(1);
            String message = matcher.group(2);
            if (receiver == null || receiver.isBlank()) receiver = ClientConnectionHandler.USER_ALL;
            connectionHandler.message(receiver, message);
            // to delete old msg
            messageField.setText("");
        } else {
            writeError("Not a valid message format.");
        }
    }

    /**
     * starts connectionHandler with given in inputs
     * @throws IOException
     */
    private void startConnectionHandler() throws IOException {
        String userName = "Patient";
        String serverAddress = serverAddressField.getText();
        int serverPort = Integer.parseInt(serverPortField.getText());
        if (notEmpty(userName,serverAddress)) {
            connectionHandler = new ClientConnectionHandler(
                    NetworkHandler.openConnection(serverAddress, serverPort), userName, this);
            new Thread(connectionHandler).start();
            rootPane.getScene().getWindow().addEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, windowCloseHandler);
        }
        else {
            writeError("Error");

        }


    }

    /**
     * terminates connectionHandler when window is Closed
     */
    private void terminateConnectionHandler() {
        rootPane.getScene().getWindow().removeEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, windowCloseHandler);
        if (connectionHandler != null) {
            connectionHandler.stopReceiving();
            connectionHandler = null;
        }
    }

    /**
     * Updating UI state by connecting or disconnecting
     */

    public void stateChanged(ClientConnectionHandler.State newState) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                connectButton.setText((newState == CONNECTED || newState == CONFIRM_DISCONNECT) ? "Disconnect" : "Connect");
            }
        });
        if (newState == DISCONNECTED) {
            terminateConnectionHandler();
        }
    }

    /**
     * sending message by pressing enter
     */
    public void sendMessage(KeyEvent keyEvent) throws ChatProtocolException {
        if (keyEvent.getCode() == KeyCode.ENTER) {
            message();
        }
    }

    /**
     * sets UserName
     * @param userName
     */
    public void setUserName(String userName) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                userNameField.setText(userName);
            }
        });
    }

    /**
     * Sets the server address.
     */

    public void setServerAddress(String serverAddress) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                serverAddressField.setText(serverAddress);
            }
        });
    }


    /**
     * Sets the server port.
     */
    public void setServerPort(int serverPort) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                serverPortField.setText(Integer.toString(serverPort));
            }
        });
    }

    /**
     * writeInfo pass message info in gui
     */
    public void writeError(String messageError) {
        this.messageArea.appendText(String.format("[ERROR] %s\n", messageError));
    }


    /**
     * writeInfo pass message info in gui
     */
    public void writeInfo(String messageInfo) {
        this.messageArea.appendText(String.format("[INFO] %s\n", messageInfo));
    }

    /**
     * write messages to another users. It always needs a String representing a sender, a String
     * representing a receiver and a String representing a message
     * correcting payload to message
     */

    public void writeMessage(String sender, String reciever, String message) {
        this.messageArea.appendText(String.format("[%s -> %s] %s\n", sender, reciever, message));
    }

    /**
     * Class WindowCloseHandler handels closing the app.
     */
    class WindowCloseHandler implements EventHandler<WindowEvent> {
        public void handle(WindowEvent event) {
            applicationClose();
        }
    }

    /**
     * to avoid leaving the user name empty and take anonymous and to avoid empty server adress
     * @param userName
     * @param serverAddress
     * @return
     */

    private boolean notEmpty(String userName , String serverAddress ) {
        if (userName.isEmpty()) {
            writeError("Please enter user name");
            return false;}
        if (serverAddress.isEmpty()) {
            writeError("Please enter valid server adress");
            return false;}

        return true;



    }


}
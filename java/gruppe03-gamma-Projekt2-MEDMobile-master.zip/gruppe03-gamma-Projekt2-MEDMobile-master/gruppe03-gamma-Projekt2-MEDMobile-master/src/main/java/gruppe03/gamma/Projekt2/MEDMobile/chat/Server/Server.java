package gruppe03.gamma.Projekt2.MEDMobile.chat.Server;


import gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol.NetworkHandler;

import java.io.IOException;
import java.io.InputStream;
import java.net.SocketException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 * Main server class , handles network connection
 */
public class Server {

    private static final Logger logger = Logger.getLogger(Server.class.getCanonicalName());

    // Server connection
    private NetworkHandler.NetworkServer<String> networkServer;
    // Connection registry
    private HashMap<String, ServerConnectionHandler> connections = new HashMap<>();

    public Server() {

    }

    /**
     * Main Class creates Server with port
     */
    public static void runServer() {

        // Parse arguments for server port.
        try {
            int port;
            port = NetworkHandler.DEFAULT_PORT;
            // Initialize server
            final Server server = new Server(port);

            // This adds a shutdown hook running a cleanup task if the JVM is terminated (kill -HUP, Ctrl-C,...)
            Runtime.getRuntime().addShutdownHook(new Thread() {
                /**
                 *
                 */
                @Override
                public void run() {
                    try {
                        Thread.sleep(200);
                        logger.info("Shutdown initiated...");
                        server.terminate();
                    } catch (InterruptedException e) {
                        logger.log(Level.WARNING, "Shutdown interrupted.", e);
                    } finally {
                        logger.info("Shutdown complete.");
                    }
                }
            });

            // Start server
            server.start();
        } catch (IOException e) {
            logger.severe("Error while starting server." + e.getMessage());
        }
    }

    /**
     * creates NetworkServer with param serverPort
     * @param serverPort
     * @throws IOException
     */
    public Server(int serverPort) throws IOException {
        logger.setLevel(Level.ALL);
        // Open server connection
        logger.info("Create server connection");
        networkServer = NetworkHandler.createServer(serverPort);
        logger.info("Listening on " + networkServer.getHostAddress() + ":" + networkServer.getHostPort());
    }

    /**
     * starts Server, waits as long as the Server is alive, it waits for connection
     */
    private void start() {
        logger.info("Server started.");
        try {

            while (true) { //runs as long no Exception is thrown.
                NetworkHandler.NetworkConnection<String> connection = networkServer.waitForConnection();

                //Creates a new Thread for every new connection is made
                ServerConnectionHandler connectionHandler = new ServerConnectionHandler(connection, connections);
                new Thread(connectionHandler).start();

                //Information about the new connection made
                logger.info(String.format("Connected new Client %s with IP:Port <%s:%d>",
                        connectionHandler.getUserName(),
                        connection.getRemoteHost(),
                        connection.getRemotePort()
                ));
            }
        } catch (SocketException e) {
            logger.log(Level.FINE, "Server connection terminated");
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Communication error", e);
        }
        // close server
        logger.info("Server Stopped.");
    }

    /**
     * closes networkServer
     */
    public void terminate() {
        try {
            logger.info("Close server port.");
            networkServer.close();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to close server connection", e);
        }
    }

}
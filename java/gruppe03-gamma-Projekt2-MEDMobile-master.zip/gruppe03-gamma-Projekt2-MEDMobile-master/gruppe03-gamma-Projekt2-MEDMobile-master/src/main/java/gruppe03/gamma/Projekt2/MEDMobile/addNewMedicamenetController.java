package gruppe03.gamma.Projekt2.MEDMobile;


import gruppe03.gamma.Projekt2.MEDMobile.Model.DateUtil;
import gruppe03.gamma.Projekt2.MEDMobile.Model.Medicament;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * use this class to add new medicament
 */

public class addNewMedicamenetController {


    @FXML // fx:id="medicamenetFeld"
    private TextField medicamenetFeld; // Value injected by FXMLLoader
    @FXML // fx:id="Tablet"
    private RadioButton Tablet; // Value injected by FXMLLoader
    @FXML // fx:id="Drops"
    private RadioButton Drops; // Value injected by FXMLLoader
    @FXML // fx:id="Syrup"
    private RadioButton Syrup; // Value injected by FXMLLoader
    @FXML // fx:id="Cream"
    private RadioButton Cream; // Value injected by FXMLLoader
    @FXML // fx:id="MGType"
    private RadioButton MGType; // Value injected by FXMLLoader
    @FXML // fx:id="AMountDrops"
    private RadioButton AMountDrops; // Value injected by FXMLLoader
    @FXML // fx:id="AMountML"
    private RadioButton AMountML; // Value injected by FXMLLoader
    @FXML // fx:id="TreeTimeDay"
    private RadioButton TreeTimeDay; // Value injected by FXMLLoader
    @FXML // fx:id="TowTImeDay"
    private RadioButton TowTImeDay; // Value injected by FXMLLoader
    @FXML // fx:id="FourTimeDay"
    private RadioButton FourTimeDay; // Value injected by FXMLLoader
    @FXML // fx:id="Daily"
    private RadioButton Daily; // Value injected by FXMLLoader
    @FXML // fx:id="AmountFiled"
    private TextField AmountFiled; // Value injected by FXMLLoader
    @FXML // fx:id="AddButton"
    private Button AddButton; // Value injected by FXMLLoader
    @FXML // fx:id="CancleButton"
    private Button CancleButton; // Value injected by FXMLLoader
    @FXML // fx:id="firstTimeButton"
    private Button firstTimeButton; // Value injected by FXMLLoader
    @FXML // fx:id="showTimeLabel"
    private Label showTimeLabel; // Value injected by FXMLLoader
    @FXML
    private CheckBox firstTimeDate;
    private Stage dialogestage;
    private boolean AddClicke = false;

    private Medicament medicament = new Medicament();


    @FXML
    private void handleCancel() {
        Stage stage = (Stage) CancleButton.getScene().getWindow();
        stage.close();
    }


    public void setMedicament(Medicament medicament) {

        this.medicament = medicament;


    }

    public boolean isAddClicked() {
        return AddClicke;
    }

    /**
     * handle the cheake box to set the time of token medicament
     * @param event
     */
    @FXML
    protected void handleShowTimeAction(ActionEvent event) {
        String pattern = "MM/dd/yyyy HH:mm:ss";
        // Create an instance of SimpleDateFormat used for formatting
        // the string representation of date according to the chosen pattern
        DateFormat df = new SimpleDateFormat(pattern);
        // Get the today date using Calendar object.
        Date today = Calendar.getInstance().getTime();
        // Using DateFormat format method we can create a string
        // representation of a date with the defined format.
        String todayAsString = df.format(today);
        showTimeLabel.setText(todayAsString);
    }

    @FXML
    void initialize() {

        // initialize the combobox with value from enum
        ComboBox<AlarmFrequency> medFreqBOX = new ComboBox<>();
        medFreqBOX.setItems(FXCollections.observableArrayList(AlarmFrequency.values()));
        // initialize the combobox with value from enum
        ComboBox<MedicalUtil.mediType> medTypeBOX = new ComboBox<>();
        medTypeBOX.setItems(FXCollections.observableArrayList(MedicalUtil.mediType.values()));
        // initialize the combobox with value from enum
        ComboBox<MedicalUtil.amountType> AMountTypeBOX = new ComboBox<>();
        AMountTypeBOX.setItems(FXCollections.observableArrayList(MedicalUtil.amountType.values()));

        // make toggle group for every enum type
        ToggleGroup AlarmFrequencyGroup = new ToggleGroup();
        TreeTimeDay.setToggleGroup(AlarmFrequencyGroup);
        TowTImeDay.setToggleGroup(AlarmFrequencyGroup);
        FourTimeDay.setToggleGroup(AlarmFrequencyGroup);
        Daily.setToggleGroup(AlarmFrequencyGroup);

        ToggleGroup MediTypeGroup = new ToggleGroup();
        Tablet.setToggleGroup(MediTypeGroup);
        Drops.setToggleGroup(MediTypeGroup);
        Syrup.setToggleGroup(MediTypeGroup);
        Cream.setToggleGroup(MediTypeGroup);

        ToggleGroup MediAmountGroup = new ToggleGroup();
        MGType.setToggleGroup(MediAmountGroup);
        AMountDrops.setToggleGroup(MediAmountGroup);
        AMountML.setToggleGroup(MediAmountGroup);


    }

    /**
     * handle add button
     */
    @FXML
    private void handleAdd() {

        medicament.setName(medicamenetFeld.getText());
        medicament.setDose((Integer.parseInt(AmountFiled.getText())));
        // very important to get first time of medicamnet
        medicament.setFirstTimeToTake(DateUtil.parse(showTimeLabel.getText()));
        if (FourTimeDay.isSelected()) {
            medicament.setAlarmFrequency(AlarmFrequency.FourTimeinDay);
        }
        if (TreeTimeDay.isSelected()) {
            medicament.setAlarmFrequency(AlarmFrequency.ThreeTimeinDay);
        }
        if (TowTImeDay.isSelected()) {
            medicament.setAlarmFrequency(AlarmFrequency.TowTimeinDay);
        }
        if (Daily.isSelected()) {
            medicament.setAlarmFrequency(AlarmFrequency.Dailly);
        }
        if (MGType.isSelected()) {
            medicament.setAmountType(MedicalUtil.amountType.MG);
        }
        if (AMountDrops.isSelected()) {
            medicament.setAmountType(MedicalUtil.amountType.DROPS);
        }
        if (AMountML.isSelected()) {
            medicament.setAmountType(MedicalUtil.amountType.ML);
        }
        if (Tablet.isSelected()) {
            medicament.setMediType(MedicalUtil.mediType.TABLET);
        }
        if (Drops.isSelected()) {
            medicament.setMediType(MedicalUtil.mediType.DROPS);
        }
        if (Syrup.isSelected()) {
            medicament.setMediType(MedicalUtil.mediType.SYRUP);
        }
        if (Cream.isSelected()) {
            medicament.setMediType(MedicalUtil.mediType.CREAM);
        }
        AddClicke = true;
        dialogestage.close();

    }


}




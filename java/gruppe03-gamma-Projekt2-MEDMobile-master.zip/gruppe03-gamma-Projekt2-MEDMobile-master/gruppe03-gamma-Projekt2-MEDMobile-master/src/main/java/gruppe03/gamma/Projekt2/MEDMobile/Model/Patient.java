package gruppe03.gamma.Projekt2.MEDMobile.Model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import gruppe03.gamma.Projekt2.MEDMobile.AlarmFrequency;



/**
 * Class patient - a user can be a patient or a nurse
 * Class holds a hash map with all medicament's of a patient as value and
 * an array list with amount and alarm frequency of the medicament as key
 */
public class Patient extends User {
	
	private HashMap<Medicament, ArrayList> medicamentInventory;
	ArrayList medicamentAmountAndAlarmFrequencyList;
	private int weight;
	private int height;
	private String username;
	private String password;
	private int age;
	
	/**
	 * @param firstname
	 * @param lastname
	 * @param age
	 * @param isMan
	 * @param insuranceNumber
	 * @param isNurse
	 */
	public Patient(String firstname, String lastname, int age,boolean isMan, String insuranceNumber, int weight,
				   int height, boolean isNurse, String username, String password) {
		super(firstname, lastname, age, insuranceNumber, isNurse, username, password);
		medicamentInventory = new HashMap<>();
		this.weight = weight;
		this.height = height;
	}
	
	/**
	 * adds a new medicament to the medicamentInventory
	 *
	 * @param medicament
	 * @param amount
	 * @param alarmFrequency
	 */
	public void addMedicament(Medicament medicament, Integer amount, AlarmFrequency alarmFrequency) {
		medicamentAmountAndAlarmFrequencyList = new ArrayList<>();
		medicamentAmountAndAlarmFrequencyList.add(amount);
		medicamentAmountAndAlarmFrequencyList.add(alarmFrequency);
		medicamentInventory.put(medicament, medicamentAmountAndAlarmFrequencyList);
	}
	
	/**
	 * @param medicament
	 * @return amount of the medicament
	 */
	public int getMedicamentAmount(Medicament medicament) {
		return (Integer)medicamentInventory.get(medicament).get(0);
	}
	
	/**
	 * @param medicament
	 * @return alarm frequency of the medicament
	 */
	public AlarmFrequency getMedicamentAlarmFrequency(Medicament medicament) {
		return (AlarmFrequency)medicamentInventory.get(medicament).get(1);
	}
	
	/**
	 * The method put will replace the value minus one for amount of a medicament.
	 * Only one unit from the MedicamentInventory-HashMap will be deleted each time this
	 * method is called
	 *
	 * @param medicament
	 */
	public void takeAMedicament(Medicament medicament){
		if(medicamentInventory.containsKey(medicament)){
			int newAmount = (Integer)medicamentAmountAndAlarmFrequencyList.get(0) - 1;
			medicamentAmountAndAlarmFrequencyList.add(0, newAmount);
			medicamentInventory.put(medicament, medicamentAmountAndAlarmFrequencyList);
		}
	}
	
	/**
	 * for more than one unit
	 *
	 * @param medicament
	 * @param takeAmount units of the medicament that will be taken
	 */
	public void takeMedicaments(Medicament medicament, int takeAmount){
		if(medicamentInventory.containsKey(medicament)){
			int oldAmount = (Integer)medicamentAmountAndAlarmFrequencyList.get(0);
			medicamentAmountAndAlarmFrequencyList.add(0, oldAmount - takeAmount);
			medicamentInventory.put(medicament, medicamentAmountAndAlarmFrequencyList);
		}
	}
	
	/**
	 * @return medicament inventory of a patient
	 */
	public HashMap<Medicament, ArrayList> getMedicamentInventory() {
		return medicamentInventory;
	}
	
	/**
	 * @return all medicament of the hash map
	 */
	public Set<Medicament> getMedicamentsFromMap() {
		return medicamentInventory.keySet();
	}
	
	/**
	 * @param medicament
	 * @return
	 */
	public int getMedicamentAmountFromMap(Medicament medicament){
		ArrayList list = medicamentInventory.get(medicament);
		return (Integer)list.get(0);
	}
	
	/**
	 * @param medicament
	 * @return
	 */
	public AlarmFrequency getAlarmFrequencyFromMap(Medicament medicament){
		ArrayList list = medicamentInventory.get(medicament);
		return (AlarmFrequency)list.get(1);
	}
	
	/**
	 * @param medicament
	 * @return true, if a a medicament amount is 0
	 */
	public boolean finishedMedicament(Medicament medicament) {
		ArrayList list = medicamentInventory.get(medicament);
		return (Integer)list.get(0) == 0;
	}
	
	/**
	 * @param password
	 * @return new password
	 */
	public String passwordChange(String password) {
		this.password = password;
		return password;
	}
	
	/**
	 * @param username
	 * @return new username
	 */
	public String usernameChange(String username) {
		this.username = username;
		return username;
	}
	
}

package gruppe03.gamma.Projekt2.MEDMobile.View;

import gruppe03.gamma.Projekt2.MEDMobile.AlarmFrequency;
import gruppe03.gamma.Projekt2.MEDMobile.Alarmpriority;
import gruppe03.gamma.Projekt2.MEDMobile.Controller.TodayDoseAlarmController;
import gruppe03.gamma.Projekt2.MEDMobile.DoseAlgorithm;
import gruppe03.gamma.Projekt2.MEDMobile.MedicalDose;
import gruppe03.gamma.Projekt2.MEDMobile.Model.MedicamentInfo;
import gruppe03.gamma.Projekt2.MEDMobile.Model.Patient;
import gruppe03.gamma.Projekt2.MEDMobile.Model.User;
import gruppe03.gamma.Projekt2.MEDMobile.chat.Client.Client;


import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import java.util.logging.Logger;

/**
 *  Controller class for the MainView gui for patients
 */
public class MainViewPatientController implements EventHandler<ActionEvent>, Initializable {
	
	private User patient=new User();
	private DoseAlgorithm doseAlgorithm =new DoseAlgorithm();

	private static final Logger logger = Logger.getLogger(Client.class.getCanonicalName());
	private Date date;
	
	@FXML // fx:id="patientName"
	private Label patientName; // Value injected by FXMLLoader
	
	@FXML // fx:id="BMR"
	private Button BMR; // Value injected by FXMLLoader
	
	@FXML // fx:id="chat"
	private Button chat; // Value injected by FXMLLoader
	
	@FXML // fx:id="idealWight"
	private Button idealWeight; // Value injected by FXMLLoader
	
	@FXML // fx:id="addMedi"
	private Button addMedi; // Value injected by FXMLLoader
	
	@FXML // fx:id="bmiResult"
	private Label bmiResult; // Value injected by FXMLLoader
	
	@FXML // fx:id="idealWeightResult"
	private Label idealWeightResult; // Value injected by FXMLLoader
	
	@FXML // fx:id="patientInfo"
	private Label patientInfo; // Value injected by FXMLLoader
	
	@FXML // fx:id="mediList"
	private TextArea mediList; // Value injected by FXMLLoader
	
	@FXML // fx:id="showNoticication1"
	private Label showNotification1;
	
	@FXML // fx:id="showNotification2"
	private Label showNotification2; // Value injected by FXMLLoader
	
	@FXML // fx:id="BMI"
	private Button BMI; // Value injected by FXMLLoader
	
	@FXML // fx:id="bmrResult"
	private Label bmrResult; // Value injected by FXMLLoader


	public MainViewPatientController() throws IOException {
		User user = new User("Max","Muster",25,"123456789",false,"0000","maxmuster@hotmail.com");
		patient=user;
		patient.setHeightCM(180);
		patient.setWeightKg(80);
		patient.setGender("m");

	}

	public void setPatientName() {
		patientName.setText(patient.getFullName());

	}
	
	public void setPatientInfo(User patient) {
		patientInfo.setStyle("-fx-border-color: #00CCFF");
		patientInfo.setText(""+patient.getFullName()+","+patient.getAge()+"("+patient.getGender()+")\n"
				+"Insurance nr. "+patient.getInsuranceNumber()+"\n"
				+"Height(cm): "+ patient.getHeightCM()+"\n"
				+"Weight(kg): "+ patient.getWeightKg());
	}
	
	private void setMedicationList(Patient patient) {
		mediList.setText(patient.getMedicamentsFromMap().toString());
	}
	
	private void setMedicationList() {
		mediList.setText(new MedicamentInfo().getMedicamentNames());
		mediList.setStyle("-fx-font-size: 25");
	}
	
	
	MedicalDose medicalDose1 = new MedicalDose(new MedicamentInfo().getDafalgan500());
	MedicalDose medicalDose2 = new MedicalDose(new MedicamentInfo().getBepanthen10());
	TodayDoseAlarmController todayDoseAlarmController = new TodayDoseAlarmController(true, medicalDose1,date, Alarmpriority.CRITICAL, AlarmFrequency.TowTimeinDay);

	private void showNotification1(){
		showNotification1.setText(todayDoseAlarmController.show(medicalDose1,Alarmpriority.CRITICAL));
		showNotification1.setStyle("-fx-border-color: red");
	}
	private void showNotification2(){
		showNotification2.setText(new TodayDoseAlarmController(true, medicalDose2, date, Alarmpriority.NORMAL,AlarmFrequency.OnceEvryTowDays).show(medicalDose2,Alarmpriority.NORMAL));
	}
	
	
	@Override
	@FXML
	public void handle(ActionEvent button) {
		if (button.getSource() == addMedi) {
			Parent root;
			try {
				// loading the fxml file
				URL fxmlResource = ClassLoader.getSystemResource("NewMedicament.fxml");
				root = FXMLLoader.load(fxmlResource);
				// fill in scene and stage setup
				Stage stage = new Stage();
				
				// configure and show stage
				stage.setTitle("Add New Medicament");
				stage.setScene(new Scene(root, 570, 500));
				stage.show();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		if (button.getSource() == chat) {
			try {
				// loading the fxml file
				URL fxmlResource = ClassLoader.getSystemResource("ChatWindow.fxml");
				Parent root = FXMLLoader.load(fxmlResource);
				// fill in scene and stage setup
				Scene scene = new Scene(root);

				// configure and show stage
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.setMinWidth(420);
				stage.setMinHeight(250);
				// window title changed to Multichat Client PM2-ZHAW
				stage.setTitle("Patient-Nurse Chat");
				stage.show();
			} catch(Exception e) {
				logger.severe("Error starting up UI" + e.getMessage());
			}
		}

		if (button.getSource() == BMR){
			if(patient != null){
			double bmr = doseAlgorithm.BMR(patient);
				bmrResult.setText("Basal-Metabolic-Rate: "+Double.toString(bmr));
			}else{
				bmrResult.setText("no patient data");
				bmrResult.setStyle("-fx-text-fill: red");
			}
		}
		if (button.getSource() == BMI) {
			if (patient!=null){
				double bmi = doseAlgorithm.BMI(patient);
				bmiResult.setText("Body-Mass-Index: "+Double.toString(bmi));


			}else{
				bmiResult.setText("no patient data");
				bmiResult.setStyle("-fx-text-fill: red");
			}
		}
		if (button.getSource() == idealWeight) {
			if (patient!=null){
				double idealWeight = doseAlgorithm.idealWeight(patient);
				idealWeightResult.setText("Ideal Weight:"+Double.toString(idealWeight));
			}else{
				idealWeightResult.setText("no patient data");
				idealWeightResult.setStyle("-fx-text-fill: red");
			}
		}
	}
	
	
	@FXML
	@Override
	public void initialize(URL url, ResourceBundle resourceBundle){
		init();
	}
	
	private void init(){
		setPatientName();
		setPatientInfo(patient);
		setMedicationList();
		showNotification1();
		showNotification2();

	}
	
	
}

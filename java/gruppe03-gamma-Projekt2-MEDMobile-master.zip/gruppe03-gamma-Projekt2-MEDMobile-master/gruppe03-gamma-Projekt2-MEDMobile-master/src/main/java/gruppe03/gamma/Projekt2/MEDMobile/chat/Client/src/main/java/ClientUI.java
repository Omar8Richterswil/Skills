package gruppe03.gamma.Projekt2.MEDMobile.chat.Client.src.main.java;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.logging.Logger;


/**
 * ClientUI extends the Application , loading the fxml file and set the scene
 */
public class ClientUI extends Application {

    private static final Logger logger = Logger.getLogger(ClientUI.class.getCanonicalName());

    @Override
    public void start(Stage primaryStage) {
        chatWindow(primaryStage);
    }

    /**
     * set the Chat Window with its Height and Width and Title
     * @param primaryStage
     */
    private void chatWindow(Stage primaryStage) {
        try {
            // loading the fxml file
            URL fxmlResource = ClassLoader.getSystemResource("ChatWindow.fxml");
            Parent root = FXMLLoader.load(fxmlResource);
            // fill in scene and stage setup
            Scene scene = new Scene(root);

            // configure and show stage
            primaryStage.setScene(scene);
            primaryStage.setMinWidth(420);
            primaryStage.setMinHeight(250);
            // window title changed to Multichat Client PM2-ZHAW
            primaryStage.setTitle("Patient-Nurse Chat");
            primaryStage.show();
        } catch(Exception e) {
            logger.severe("Error starting up UI" + e.getMessage());
        }
    }

}
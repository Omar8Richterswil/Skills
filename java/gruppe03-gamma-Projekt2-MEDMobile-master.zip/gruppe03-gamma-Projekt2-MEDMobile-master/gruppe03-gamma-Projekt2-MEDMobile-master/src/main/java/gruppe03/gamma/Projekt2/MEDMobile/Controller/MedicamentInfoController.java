package gruppe03.gamma.Projekt2.MEDMobile.Controller;

import gruppe03.gamma.Projekt2.MEDMobile.*;
import gruppe03.gamma.Projekt2.MEDMobile.Model.Medicament;
import gruppe03.gamma.Projekt2.MEDMobile.Model.MedicamentInfo;


import java.util.ArrayList;
import java.util.logging.Logger;

/**
 * MedicamentInfoController is used as Controller class for the Medicaments  and the MedicamentInfo
 */
public class MedicamentInfoController  {

    private final MedicamentInfo medicamentInfo=new MedicamentInfo();
    private static final Logger logger = Logger.getLogger(TodayDoseAlarmController.class.getCanonicalName());

    public ArrayList<Medicament> getMedicamentList (){
        return medicamentInfo.getMedicamentList();
    }

    /**
     * Function addMedicament is to add a new Medicament to the List
     * In the application it means to add a Medicament to the Database, which can later be prescribed to a patient
     * it creates a Medicament from the given in parameters, if the medicament already exists it will create a logger message.
     * @param name Name of the Medicament (f.e. "Dafalgan")
     * @param mediType will be choosen from a dropdown menu (f.e. TABLET)
     * @param amountType will be choosen from a dropdown menu (f.e. MG)
     * @param dose will be given in (f.e. 500, for 500mg)
     */
    public void addMedicament (String name, MedicalUtil.mediType mediType, MedicalUtil.amountType amountType, int dose, AlarmFrequency alarmFrequency) {
        Medicament newMedicament = new Medicament(name, mediType, amountType, dose, alarmFrequency);
        if (medicamentInfo.validateEntry(newMedicament)) {
            medicamentInfo.getMedicamentList().add(newMedicament);
        } else {
            logger.info("This Medicament already exists");
            //TODO: Can we Call action on logger messages or how can we show the message to the user?
        }
    }

    /**
     * Uses medicamentInfo Method getMedicamentfromNameandDose to return the Medicament, returns null if the Medicament doesnt exist.
     * @param name Name of the Medicament (f.e. "Dafalgan")
     * @param dose Dose of the Medicament (f.e. 500, for 500 mg)
     * @return medicament
     */
        public Medicament getMedicamentByNameAndDose (String name, int dose){
           Medicament medicament =  medicamentInfo.getMedicamentfromNameAndDose(name,dose);

           return medicament;
        }

        public MedicalUtil.amountType getAmountType (Medicament medicament){
            return medicament.getAmountType();
        }

        public MedicalUtil.mediType getMediType (Medicament medicament){
            return medicament.getMediType();
        }

        public String getName (Medicament medicament){
            return medicament.getName();
        }

        public int getDose (Medicament medicament) {
            return medicament.getDose();
        }

}

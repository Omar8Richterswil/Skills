package gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol;

public class ChatProtocolException extends Exception {

    public ChatProtocolException(String message) {
        super(message);
    }

    public ChatProtocolException(String message, Throwable cause) {
        super(message, cause);
    }

    public ChatProtocolException(Throwable cause) {
        super(cause);
    }

}


package gruppe03.gamma.Projekt2.MEDMobile;

import gruppe03.gamma.Projekt2.MEDMobile.Model.Medicament;

import java.time.LocalTime;

/**
 * Define the amount of dose
 */

public class Dose {
    private final int id;
    private final transient Medicament drug;
    private LocalTime time;
    private int shiftInDays;

    public Dose(int id, Medicament drug, LocalTime time, int shiftInDays) {
        this.id = id;
        this.drug = drug;
        this.time = time;
        this.shiftInDays = shiftInDays;
    }

    public LocalTime getTime() {
        return time;
    }

    public void setTime(LocalTime time) {
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public int getShiftInDays() {
        return shiftInDays;
    }

    public void setShiftInDays(int shiftInDays) {
        this.shiftInDays = shiftInDays;
    }
}

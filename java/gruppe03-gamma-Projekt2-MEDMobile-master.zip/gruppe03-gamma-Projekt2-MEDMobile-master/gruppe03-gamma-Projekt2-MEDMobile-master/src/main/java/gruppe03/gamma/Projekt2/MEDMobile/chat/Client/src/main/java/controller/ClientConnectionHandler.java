package gruppe03.gamma.Projekt2.MEDMobile.chat.Client.src.main.java.controller;

import gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol.ChatConfig;
import gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol.ChatProtocolException;
import gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol.ConnectionHandler;
import gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol.NetworkHandler;

import java.util.logging.Logger;

import static gruppe03.gamma.Projekt2.MEDMobile.chat.Client.src.main.java.controller.ClientConnectionHandler.State.*;


/**
 * Class ClientConnectionHandler is a connectionHandler for the Client with whom he can communicate with the Network Server
 */
public class ClientConnectionHandler extends ConnectionHandler {
    private static final Logger logger = Logger.getLogger(ClientConnectionHandler.class.getCanonicalName());
    private final NetworkHandler.NetworkConnection<String> connection;
    private final ChatWindowController controller;
    private String userName;
    private State state = State.NEW;


    enum State {NEW, CONFIRM_CONNECT, CONNECTED, CONFIRM_DISCONNECT, DISCONNECTED}


    public ClientConnectionHandler(NetworkHandler.NetworkConnection<String> connection,
                                   String userName,
                                   ChatWindowController controller) {
        super(connection);
        this.connection = connection;
        this.userName = (userName == null || userName.isBlank()) ? USER_NONE : userName;
        this.controller = controller;
    }


    @Override
    public void startReceiving() {
        logger.info("Starting Connection Handler");
        Exception exception = startReceivingExp();
        if(exception != null){
            this.setState(DISCONNECTED);
            logger.info("Unregistered because connection terminated" + exception.getMessage());
        }
        logger.info("Stopped Connection Handler");
    }

    @Override
    protected void getConnected(ChatConfig chatConfig){
        logger.severe("Illegal connect request from server");
    }

    @Override
    protected void getConfirmed(ChatConfig chatConfig){
        if (state == CONFIRM_CONNECT) {
            this.userName = chatConfig.getReceiver();
            controller.setUserName(userName);
            controller.setServerPort(connection.getRemotePort());
            controller.setServerAddress(connection.getRemoteHost());
            controller.writeInfo(chatConfig.getPayload());
            logger.info("CONFIRM: " + chatConfig.getPayload());
            this.setState(CONNECTED);
        } else if (state == CONFIRM_DISCONNECT) {
            controller.writeInfo(chatConfig.getPayload());
            logger.info("CONFIRM: " + chatConfig.getPayload());
            this.setState(DISCONNECTED);
        } else {
            logger.severe("confirm message: " + chatConfig.getPayload());
        }
    }

    @Override
    protected void getDisconnected(ChatConfig chatConfig){
        if (state == DISCONNECTED) {
            logger.info("DISCONNECT: Already in disconnected: " + chatConfig.getPayload());
            return;
        }
        controller.writeInfo(chatConfig.getPayload());
        logger.info("DISCONNECT: " + chatConfig.getPayload());
        this.setState(DISCONNECTED);
    }

    @Override
    protected void getMessage(ChatConfig chatConfig){
        if (state != CONNECTED) {
            logger.info("MESSAGE: Illegal state " + state + " for message: " + chatConfig.getPayload());
            return;
        }
        controller.writeMessage(chatConfig.getSender(), chatConfig.getReceiver(), chatConfig.getPayload());
        logger.info("MESSAGE: From " + chatConfig.getSender() + " to " + chatConfig.getReceiver() + ": " + chatConfig.getPayload());
    }

    @Override
    protected void getError(ChatConfig chatConfig){
        controller.writeError(chatConfig.getPayload());
        logger.info("ERROR: " + chatConfig.getPayload());
    }

    /**
     * connects and thus sets UserName with state type to CONFIRM_CONNECT
     * @throws ChatProtocolException
     */
    public void connect() throws ChatProtocolException {
        if (state != NEW) throw new ChatProtocolException("Illegal state for connect: " + state);
        this.sendData(new ChatConfig(userName, USER_NONE, ChatConfig.Type.CONNECT, null));
        this.setState(CONFIRM_CONNECT);
    }

    /**
     * disconnects and thus sets UserName with state type to CONFIRM_DISCONNECT
     * @throws ChatProtocolException
     */
    public void disconnect() throws ChatProtocolException {
        if (state != NEW && state != CONNECTED)
            throw new ChatProtocolException("Illegal state for disconnect: " + state);
        this.sendData(new ChatConfig(userName, USER_NONE, ChatConfig.Type.DISCONNECT, null));
        this.setState(CONFIRM_DISCONNECT);
    }

    /**
     * msets UserName with state type to MESSAGE
     * @param receiver
     * @param message
     * @throws ChatProtocolException
     */
    public void message(String receiver, String message) throws ChatProtocolException {
        if (state != CONNECTED) throw new ChatProtocolException("Illegal state for message: " + state);
        this.sendData(new ChatConfig(userName, receiver, ChatConfig.Type.MESSAGE, message));
    }

    public State getState() {
        return this.state;
    }


    public void setState(State newState) {
        this.state = newState;
        controller.stateChanged(newState);
    }

    @Override
    public void run() {
        this.startReceiving();
    }
}
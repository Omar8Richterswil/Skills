package gruppe03.gamma.Projekt2.MEDMobile;


import gruppe03.gamma.Projekt2.MEDMobile.Model.Medicament;

/**
 * in this class will caculate the dose in the packet of the medicine
 */
public class MedicalDose {
    private final Medicament medicament;
    private final int timestampOftreatment;
    private final int maxDailydose;
    //in hours
    private final int timeToNextTreatment;


    public MedicalDose(Medicament medicament) {
        this.medicament = medicament;
        timestampOftreatment = medicalDoseAlgorithm(medicament);
        maxDailydose = 1;
        timeToNextTreatment = 24 / maxDailydose;
    }


    public int medicalDoseAlgorithm(Medicament medicament) {
        int timestamp = 0;
        if (medicament.isAcidblocker()) {
            timestamp = 2000;
        }
        if (medicament.isAntiasthmatic()) {
            timestamp = 2000;
        }

        if (medicament.isAntirheumatic()) {
            timestamp = 2000;
        }
        if (medicament.isCortisone()) {
            timestamp = 800;
        }
        return timestamp;
    }

    public String toString() {
        return medicament.getName() + " Dose " + medicament.getDose();
    }

    /**
     * when it going to be empty but , the notification
     * will notify the user before its finsh in 2 dose
     * @return
     */
    public boolean isEmpty() {
        int restAmount = 2;
        // to insure that the backet give notification when there is at less 2 dose left
        int originalAmount = medicament.getDose();
        return restAmount != originalAmount;
    }
}


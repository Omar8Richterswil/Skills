package gruppe03.gamma.Projekt2.MEDMobile.chat.Client;



import gruppe03.gamma.Projekt2.MEDMobile.chat.Client.src.main.java.ClientUI;
import javafx.application.Application;

import java.util.logging.Logger;


/**
 * The main class to start the app and the Gui client.
 */
public class Client {
    private static final Logger logger = Logger.getLogger(Client.class.getCanonicalName());

    /**
     * Main Class starts Client
     * @param
     */
    public static void runClient() {

        /** logging manger
        try {
            InputStream config = Client.class.getClassLoader().getResourceAsStream("log.properties");
            LogManager.getLogManager().readConfiguration(config);
        } catch (IOException e) {
            logger.log(Level.CONFIG,"No log.properties", e);
        }*/
        // Start UI
        logger.info("Starting Client Application");
        Application.launch(ClientUI.class);
        logger.info("Client Application ended");
    }
}


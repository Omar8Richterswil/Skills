package gruppe03.gamma.Projekt2.MEDMobile;

import gruppe03.gamma.Projekt2.MEDMobile.Model.DateUtil;
import gruppe03.gamma.Projekt2.MEDMobile.Model.Medicament;

import java.time.LocalTime;
import java.util.Date;

public class TodayDose {

    private final Medicament drug;
    private final int id;
    private final LocalTime time;
    private TakeDose takeDose;
    private final int shiftInDays;

    public TodayDose(int id, Medicament drug, LocalTime time, TakeDose takeDose, int shiftInDays) {
        this.drug = drug;
        this.id = id;
        this.time = time;
        this.takeDose = takeDose;
        this.shiftInDays = shiftInDays;
    }

    public TakeDose getTakeDose() {
        return takeDose;
    }

    public void setTakeDose(TakeDose takeDose) {
        this.takeDose = takeDose;
    }

    public String getDrugName() {
        return drug != null ? drug.getName() : "";
    }

    public LocalTime getTime() {
        return time;
    }

    public int getId() {
        return id;
    }

    public boolean wasTaken() {
        return takeDose != null && takeDose.isTaken();
    }

    public DateUtil getTakenTime() {
        return takeDose.getTime();
    }


    public void setTaken(DateUtil takenTime) {
        int i = (int) (new Date().getTime() / 1000);
        AlarmFrequency hour = AlarmFrequency.hourFrequency(i);


        takeDose = new TakeDose(
                0,
                takenTime,

                true);
    }

    public Medicament getDrug() {
        return drug;
    }

    public DateUtil getEstimatedDateTime() {
        if (takeDose != null && takeDose.getTime() != null) {
            return takeDose.getTime();
        } else {

            // todo fix return the rest of time
            return takeDose.getTime();
        }
    }

    public String getMessage() {
        return getDrugName() + ": " + getEstimatedDateTime().toString();
    }

}

package gruppe03.gamma.Projekt2.MEDMobile.Model;


public class User {

	
	private String firstname;
	private String lastname;
	private int age;
	private String insuranceNumber;
	private boolean isNurse = false;
	private int weightKg;
	private int heightCM;
	private String gender;
	private String password;
	private String username;
	
	/**
	 *
	 * @param firstname
	 * @param lastname
	 * @param age
	 * @param insuranceNumber
	 * @param isNurse
	 */
	public  User(String firstname, String lastname, int age, String insuranceNumber, boolean isNurse, String password, String username){
		this.firstname = firstname;
		this.lastname = lastname;
		this.age = age;
		this.insuranceNumber = insuranceNumber;
		this.isNurse = isNurse;
		this.password = password;
		this.username = username;
	}

	public User(){
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		age = age;
	}
	
	public int getHeightCM() {
		return heightCM;
	}
	
	public void setHeightCM(int heightCM) {
		this.heightCM = heightCM;
	}
	
	public int getWeightKg() {
		return weightKg;
	}
	
	public void setWeightKg(int weightKg) {
		this.weightKg = weightKg;
	}
	
	public String getFirstname(){
		return firstname;
	}
	
	public void setFirstname(String name){
		this.firstname = name;
	}
	
	public String getLastname() {
		return lastname;
	}
	
	public void setLastname(String name){
		this.lastname = name;
	}

	public String getFullName(){

		return firstname + ", " + lastname;
	}

	public String getInsuranceNumber(){
		return insuranceNumber;
	}

	public void setInsuranceNumber(String insuranceNumber){
		this.insuranceNumber = insuranceNumber;
	}
	
	public void isNurse(){
		isNurse = true;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
}


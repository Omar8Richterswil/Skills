package gruppe03.gamma.Projekt2.MEDMobile;

import gruppe03.gamma.Projekt2.MEDMobile.Model.User;

/**
 * Class DoseAlgorithm has 3 different Calculations, the BMI, the BMR and the idealWeight(from height)
 */
public class DoseAlgorithm {

    private double WeightKg  ;
    private int Dosage;

    private static int weightBasedDividedDoseCalculator(int WeightKg, int Dosage) {

        int Dose = WeightKg * Dosage;
        return Dose;
    }

    //https://reference.medscape.com/calculator/weight-dosing

    /**
     * Body-Mass-Index Calculation Function which uses User parameter
     * @param user
     * @return
     */
    public double BMI (User user){
       int userWeightKg = user.getWeightKg();
       double userHeightM = user.getHeightCM()*0.01;
       double bmi = userWeightKg / (userHeightM * userHeightM);
        bmi = Math.round(100.0 * bmi) / 100.0;
        return bmi;
    }

    /**
     * Basal-Metabolic-Rate Calculation Function which uses User parameter
     * different outcomes for Male and Female with same attributes
     * @param user
     * @return
     */
    public double BMR (User user){
       int userWeightKg = user.getWeightKg();
       int userHeightCm = user.getHeightCM();
       int userAge = user.getAge();

       if(user.getGender().equals("f")){
       // for women
       double bmr = 655 + (9.6 * userWeightKg)+ (1.8 * userHeightCm) - (4.7 * userAge);
       return  bmr;
       } else{
           // for men
           double bmr = 66 + (13.7 * userWeightKg)+ (5 * userHeightCm) - (6.8 * userAge);
           return bmr;
       }

    }

    /**
     * idealWeight Calculation Function based on Users Height
     * different outcomes for Male and Female with same attributes
     * @param user
     * @return
     */
    public double idealWeight(User user){

        int userHeightCm = user.getHeightCM();
        if (user.getGender().trim().equals("f")) {
            // for women
            double idealWeight = 45.5 + ((userHeightCm - 152) * 0.9);
            return idealWeight;
        } else {
            // for men
            double idealWeight = 50 + ((userHeightCm - 152) * 0.9);
            return idealWeight;
        }
    }
}

package gruppe03.gamma.Projekt2.MEDMobile.chat.Protocol;

import java.io.EOFException;
import java.io.IOException;
import java.net.SocketException;
import java.util.logging.Logger;

/**
 * ConnectionHandler is an Abstract Class which avoids the duplicating code between
 * handler connection for both client and server
 * and implements Runnable interface
 */

public abstract class ConnectionHandler implements Runnable{
    private static final Logger logger = Logger.getLogger(ConnectionHandler.class.getCanonicalName());
    public static final String USER_NONE = "";
    public static final String USER_ALL = "*";
    private String userName;
    protected final NetworkHandler.NetworkConnection<String> connection;
    protected ConnectionHandler(NetworkHandler.NetworkConnection<String> connection) {
        this.connection = connection;
    }

    // processData data was a very big methode so its better to divided into these abstract methods like enum type
    protected abstract void getConnected(ChatConfig chatConfig) throws ChatProtocolException;
    protected abstract void getConfirmed(ChatConfig chatConfig) throws ChatProtocolException;
    protected abstract void getDisconnected(ChatConfig chatConfig) throws ChatProtocolException;
    protected abstract void getMessage(ChatConfig chatConfig) throws ChatProtocolException;
    protected abstract void getError(ChatConfig chatConfig) throws ChatProtocolException;
    public abstract void startReceiving();

    /**
     * getData method was a part from startReceiving() method
     */

    public void getData() throws IOException, ClassNotFoundException {
        logger.info("Start receiving data...");
        while (connection.isAvailable()) {
            String data = connection.receive();
            processData(data);
        }
        logger.info("Stopped receiving data");
    }

    /**
     *   stopReceiving method was in both client and server
     *   use to implement it in the abstract class
     */

    public void stopReceiving() {
        logger.info("Closing Connection Handler to Server");
        try {
            logger.info("Stop receiving data...");
            connection.close();
            logger.info("Stopped receiving data.");
        } catch (IOException e) {
            logger.warning("Failed to close connection." + e.getMessage());
        }
        logger.info("Closed Connection Handler to Server");
    }
    /**
     *   processData method was in both client and server class with more than 40 lines
     *   now this method takes the enum and of which type it is and implements it
     */

    protected void processData(String data) {
        try {
            // parse data content
            ChatConfig chatConfig = ChatConfig.dataString(data);
            // dispatch operation based on type parameter
            switch (chatConfig.getType()) {
                case CONNECT:
                    getConnected(chatConfig);
                    break;
                case CONFIRM:
                    getConfirmed(chatConfig);
                    break;
                case DISCONNECT:
                    getDisconnected(chatConfig);
                    break;
                case MESSAGE:
                    getMessage(chatConfig);
                    break;
                case ERROR:
                    getError(chatConfig);
                    break;
                default:
                    logger.info("Unknown data type received: " + chatConfig.getType());
                    break;
            }
        } catch (ChatProtocolException e) {
            logger.severe("Error while processing data: " + e.getMessage());
            sendData(new ChatConfig(USER_NONE, userName, ChatConfig.Type.ERROR, e.getMessage()));
        }
    }

    /**
     *   sendData method was in both client and server , it sends data when
     *   there is a connection , otherwise it gives exception errors
     */

    public void sendData(ChatConfig chatConfig) {
        if (connection.isAvailable()) {
            String data = chatConfig.toString();
            try {
                connection.send(data);
            } catch (SocketException e) {
                logger.info("Connection closed: " + e.getMessage());
            } catch (EOFException e) {
                logger.info("Connection terminated by remote");
            } catch (IOException e) {
                logger.info("Communication error: " + e.getMessage());
            }
        }
    }

    /**
     *   startReceivingException was a part from startReceiving method
     */
    public Exception startReceivingExp(){
        Exception exception = null;
        try {
            getData();
        } catch (SocketException e) {
            logger.info("Connection terminated locally");
            exception = e;
        } catch (EOFException e) {
            logger.info("Connection terminated by remote");
            exception = e;
        } catch (IOException e) {
            logger.severe("Communication error" + e);
        } catch (ClassNotFoundException e) {
            logger.severe("Received object of unknown type" + e.getMessage());
        }
        return exception;
    }


}
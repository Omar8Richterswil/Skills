package gruppe03.gamma.Projekt2.MEDMobile;

import gruppe03.gamma.Projekt2.MEDMobile.Model.User;
import java.sql.Date;


/**
 * Class nurse - a user can be a patient or a nurse
 */
public class Nurse extends User {
	private boolean isNurse = true;
	private String password;
	private String username;
	public Nurse(String vorname, String nachname, int age, String insuranceNumber, boolean isNurse, String password, String username){
		super(vorname, nachname, age, insuranceNumber, isNurse, password, username);
	}
	
	/**
	 * @param password
	 * @return new password
	 */
	public String passwordchange(String password) {
		
		this.password = password;
		
		return password;
		
	}
	
	/**
	 * @param username
	 * @return new username
	 */
	public String usernameChange(String username) {
		this.username = username;
		
		return username;
	}
}

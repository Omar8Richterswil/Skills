package gruppe03.gamma.Projekt2.MEDMobile.Model;

import gruppe03.gamma.Projekt2.MEDMobile.AlarmFrequency;
import gruppe03.gamma.Projekt2.MEDMobile.MedicalUtil;

import java.util.Date;
import java.util.Objects;

/**
 * Medicament Class creates instance Medicament.
 * Has Constructor for Nurse to Create a Medicament in the Application
 */
public class Medicament {
    private String name;
    private MedicalUtil.amountType amountType;
    private MedicalUtil.mediType mediType;
    private int dose;
    private AlarmFrequency alarmFrequency;
    private boolean cortisone;
    private boolean antirheumatic;
    private boolean antiasthmatic;
    private boolean acidblocker;
    private Date firstTimeToTake;

    public Medicament(String name, MedicalUtil.mediType mediType, MedicalUtil.amountType amountType, int dose, AlarmFrequency alarmFrequency) {
        this.name = name;
        this.dose = dose;
        this.amountType = amountType;
        this.mediType = mediType;
        this.alarmFrequency = alarmFrequency;
    }

    public Medicament() {

    }

    public Medicament(String name, MedicalUtil mediType, MedicalUtil amountType, int dose, AlarmFrequency alarmfrequency, Date firstTimeToTake) {
        this.name = name;
        this.dose = dose;

        this.firstTimeToTake = firstTimeToTake;
        cortisone = false;
        antirheumatic = false;
        antiasthmatic = false;
        acidblocker = false;
    }

    public MedicalUtil.amountType getAmountType() {
        return amountType;
    }

    public void setAmountType(MedicalUtil.amountType amountType) {
        this.amountType = amountType;
    }

    public MedicalUtil.mediType getMediType() {
        return mediType;
    }

    public void setMediType(MedicalUtil.mediType mediType) {
        this.mediType = mediType;
    }

    public AlarmFrequency getAlarmFrequency() {
        return alarmFrequency;
    }

    public void setAlarmFrequency(AlarmFrequency alarmFrequency) {
        this.alarmFrequency = alarmFrequency;
    }

    public Date getFirstTimeToTake() {
        return firstTimeToTake;
    }

    public void setFirstTimeToTake(Date firstTimeToTake) {
        this.firstTimeToTake = firstTimeToTake;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDose() {
        return dose;
    }

    public void setDose(int dose) {
        this.dose = dose;
    }

    public boolean isAcidblocker() {
        return acidblocker;
    }

    public void setAcidblocker(boolean acidblocker) {
        this.acidblocker = acidblocker;
    }

    public boolean isAntiasthmatic() {
        return antiasthmatic;
    }

    public void setAntiasthmatic(boolean antiasthmatic) {
        this.antiasthmatic = antiasthmatic;
    }

    public boolean isAntirheumatic() {
        return antirheumatic;
    }

    public void setAntirheumatic(boolean antirheumatic) {
        this.antirheumatic = antirheumatic;
    }

    public boolean isCortisone() {
        return cortisone;
    }

    public void setCortisone(boolean cortisone) {
        this.cortisone = cortisone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Medicament that = (Medicament) o;
        return dose == that.dose &&
                cortisone == that.cortisone &&
                antirheumatic == that.antirheumatic &&
                antiasthmatic == that.antiasthmatic &&
                acidblocker == that.acidblocker &&
                Objects.equals(name, that.name) &&
                amountType == that.amountType &&
                mediType == that.mediType &&
                alarmFrequency == that.alarmFrequency;
    }

}

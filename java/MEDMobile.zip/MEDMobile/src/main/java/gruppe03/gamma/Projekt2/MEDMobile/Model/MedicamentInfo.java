package gruppe03.gamma.Projekt2.MEDMobile.Model;

import gruppe03.gamma.Projekt2.MEDMobile.AlarmFrequency;
import gruppe03.gamma.Projekt2.MEDMobile.MedicalUtil;


import java.util.ArrayList;


/**
 * MedicamentInfo creates a Set for all Medicaments safed in the Application to represent a Database of Medicaments
 */
public class MedicamentInfo {
    private ArrayList<Medicament> medicamentList;
    /**
     * to demonstrate it will be already filled with 4 medicaments.
     */
    private Medicament dafalgan500 = new Medicament("Dafalgan", MedicalUtil.mediType.TABLET, MedicalUtil.amountType.MG, 500, AlarmFrequency.Dailly);
    private Medicament dafalgan1000 = new Medicament("Dafalgan", MedicalUtil.mediType.TABLET, MedicalUtil.amountType.MG, 1000,AlarmFrequency.FourTimeinDay);
    private Medicament bisolvon200 = new Medicament("Bisolvon", MedicalUtil.mediType.SYRUP, MedicalUtil.amountType.ML, 200,AlarmFrequency.Dailly);
    private Medicament bepanthen10 = new Medicament("Bepathen", MedicalUtil.mediType.DROPS, MedicalUtil.amountType.ML, 10,AlarmFrequency.FourTimeinDay);

    public MedicamentInfo(){
        medicamentList= new ArrayList<>();
        medicamentList.add(dafalgan500);
        medicamentList.add(dafalgan1000);
        medicamentList.add(bisolvon200);
        medicamentList.add(bepanthen10);
    }

    public ArrayList<Medicament> getMedicamentList() {
        return medicamentList;
    }

    public void setMedicamentList(ArrayList<Medicament> medicamentList) {
        this.medicamentList = medicamentList;
    }

    public void addMedicament (Medicament medicament){
            medicamentList.add(medicament);
    }

    /**
     * validates if Medicament already exists in MedicamentList by its Name and Dose (these two are a Unique combination).
     * @param medicament
     * @return isvalid returns false if entry already exists, returns true if not.
     */
    public boolean validateEntry(Medicament medicament) {
        boolean isvalid=true;
        Medicament comparemedi;
        for (int i = 0; i< medicamentList.size();i++){
            comparemedi=medicamentList.get(i);
            if (comparemedi.getName()==medicament.getName()&&comparemedi.getDose()==medicament.getDose()){
                isvalid=false;
            }
        }
        return isvalid;
    }

    /**
     * This function will be used, if the user enters a Medicament name and Dose, he will get a Medicament in return.
     * @param name Name of the Medicament (f.e. "Dafalgan")
     * @param dose Dose of the Medicament (f.e. 500, for 500 mg)
     * @return if Medicament exists its the Medicament, else its null, which can be handled into a message.
     */
    public Medicament getMedicamentfromNameAndDose (String name, int dose){
        Medicament returnmedi = null;
        Medicament compareMedi;
        for (int i= 0; i<medicamentList.size(); i++){
            compareMedi = medicamentList.get(i);

            if (compareMedi.getName().equals(name)&& compareMedi.getDose()==dose){
            returnmedi= medicamentList.get(i);
            }
        }


        return returnmedi;
    }
    
    
    public String getMedicamentNames(){
        StringBuilder medicamentName = new StringBuilder();
        for (Medicament medicament : medicamentList){
            medicamentName.append(medicament.getName()).append("        ").append(medicament.getMediType().name()).append("        ").append(medicament.getDose()).append("  ml/mg").append("\n");
        }
        return String.valueOf(medicamentName);
    }
    
    
    public Medicament getDafalgan500(){
        return dafalgan500;
    }
    
    public Medicament getBepanthen10(){
        return bepanthen10;
    }
  
    public Medicament getBisolvon200(){
        return bisolvon200;
    }
}

package gruppe03.gamma.Projekt2.MEDMobile.View;

import gruppe03.gamma.Projekt2.MEDMobile.Model.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.net.URL;

/**
 * this class to control the log in page
 */
public class RegistrationFormController {
    private final User user = new User();

    // adding name field
    @FXML
    private TextField nameField;

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button submitButton;

    @FXML
    private Button newUserButton;

    /**
     * handle the submint button , which load the main view window
     *
     * @param event
     */

    @FXML
    protected void handleSubmitButtonAction(ActionEvent event) {
        String userName = user.getUsername();
        String password = user.getPassword();
        Window owner = submitButton.getScene().getWindow();
        if (nameField.getText().isEmpty()) {
            AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                    "Please enter your name");
            return;
        }
        if (emailField.getText().isEmpty()) {
            AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                    "Please enter your email id");
            return;
        }
        if (passwordField.getText().isEmpty()) {
            AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                    "Please enter a password");
            return;
        }

        AlertHelper.showAlert(Alert.AlertType.CONFIRMATION, owner, "Registration Successful!",
                "Welcome " + nameField.getText());

        if ((nameField.getText().trim().equals(userName) && passwordField.getText().trim().equals(password))) {
            // cheake for username and password  if its good will fo to main view
            Parent root;
            try {
                URL fxmlResource = ClassLoader.getSystemResource("MainViewPatient.fxml");
                root = FXMLLoader.load(fxmlResource);
                Stage stage = new Stage();
                stage.setTitle("Main");
                stage.setScene(new Scene(root, 1000, 700));
                stage.show();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if ((nameField.getText().trim().equals("Admin") && passwordField.getText().trim().equals("Admin"))) {
            // check for username and password  if its good will fo to main view
            Parent root;
            try {
                URL fxmlResource = ClassLoader.getSystemResource("MainViewPatient.fxml");
                root = FXMLLoader.load(fxmlResource);
                Stage stage = new Stage();
                stage.setTitle("main");
                stage.setScene(new Scene(root, 1000, 700));
                stage.show();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * handle the add new user button which load the new user window
     *
     * @param event
     */
    @FXML

    public void handleAddNewUser(ActionEvent event) {
        Parent root;
        try {
            URL fxmlResource = ClassLoader.getSystemResource("addNewUser.fxml");
            root = FXMLLoader.load(fxmlResource);
            Stage stage = new Stage();
            stage.setTitle("Add New User");
            stage.setScene(new Scene(root, 750, 550));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public String getNameField() {
        return nameField.getText();
    }

}

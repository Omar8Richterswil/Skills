package gruppe03.gamma.Projekt2.MEDMobile.chat;

import gruppe03.gamma.Projekt2.MEDMobile.chat.Client.Client;
import gruppe03.gamma.Projekt2.MEDMobile.chat.Server.Server;

import java.io.IOException;

import static java.lang.Thread.sleep;

public class Chat {


    public Chat() throws IOException {
    }

    public static void main(String[] args) throws InterruptedException {
        Server.runServer();
        Client.runClient();

    }
}

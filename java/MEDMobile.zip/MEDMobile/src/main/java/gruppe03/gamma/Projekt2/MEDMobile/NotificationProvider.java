package gruppe03.gamma.Projekt2.MEDMobile;

import javax.management.Notification;
import java.util.List;

public interface NotificationProvider {


    String show(MedicalDose medicalDose, Alarmpriority alarmpriority);

    void show(List<MedicalDose> medicalDoseList, Alarmpriority alarmpriority);


    Notification getResetNotification();

    int getNextDoseId();

    Notification getNextDoseNotification();


}

package gruppe03.gamma.Projekt2.MEDMobile.Controller;


import gruppe03.gamma.Projekt2.MEDMobile.AlarmFrequency;
import gruppe03.gamma.Projekt2.MEDMobile.Alarmpriority;
import gruppe03.gamma.Projekt2.MEDMobile.MedicalDose;
import gruppe03.gamma.Projekt2.MEDMobile.NotificationProvider;

import javax.management.Notification;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;


/**
 * this class to display how oft gives the dose in a day
 */

public class TodayDoseAlarmController implements NotificationProvider {

    private Boolean active;
    private MedicalDose medicalDose;
    private Date medNotified;
    private Alarmpriority alarmpriority;
    private AlarmFrequency alarmFrequency;
    private static final Logger logger = Logger.getLogger(TodayDoseAlarmController.class.getCanonicalName());


    /**
     * define the dose param. for today dose
     * @param active
     * @param medicalDose
     * @param medNotified
     * @param alarmpriority
     * @param alarmFrequency
     */
    public TodayDoseAlarmController(Boolean active, MedicalDose medicalDose, Date medNotified,
                                    Alarmpriority alarmpriority, AlarmFrequency alarmFrequency) {
        this.active = active;
        this.medicalDose = medicalDose;
        this.medNotified = medNotified;
        this.alarmpriority = alarmpriority;
        this.alarmFrequency = alarmFrequency;
    }

    public Alarmpriority getAlarmpriority() {
        return alarmpriority;
    }

    public void setAlarmpriority(Alarmpriority alarmpriority) {
        this.alarmpriority = alarmpriority;
    }



    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }



    public MedicalDose getMedicalDose() {
        return medicalDose;
    }

    public void setMedicalDose(MedicalDose medicalDose) {
        this.medicalDose = medicalDose;
    }



    public Date getMedNotified() {
        return medNotified;
    }

    public void setMedNotified(Date medNotified) {
        this.medNotified = medNotified;
    }

    public AlarmFrequency getAlarmFrequency() {
        return alarmFrequency;
    }

    public void setAlarmFrequency(AlarmFrequency alarmFrequency) {
        this.alarmFrequency = alarmFrequency;
    }


    @Override
    public String toString() {
        return "TodayDoseAlarmController{" +
                "active=" + active +
                ", medicalDose=" + medicalDose +
                ", medNotified=" + medNotified +
                ", alarmpriority=" + alarmpriority +
                ", alarmFrequency=" + alarmFrequency +
                '}';
    }

    /**
     * give notification how much should be the dose and what kind of priority
     * @param medicalDose
     * @param alarmpriority
     * @return
     */
    @Override
    public String show(MedicalDose medicalDose , Alarmpriority alarmpriority) {
        String info = "";
        info = "    show: " + medicalDose.toString() + "\n\n    alarm is type: is " + alarmpriority;
        return info;

    }

    /**
     * second method to show list of the medicament with its priority
     * @param medicalDoseList
     * @param alarmpriority
     */
    @Override
    public void show(List<MedicalDose> medicalDoseList ,  Alarmpriority alarmpriority) {
        logger.info("show " + medicalDose.toString() + " alarm is type is " + alarmpriority);
        if (medicalDoseList == null || medicalDose.isEmpty()) {
            hideNotifications();
        } else {
            showNotification(medicalDose, alarmpriority);
        }


    }


    private synchronized void hideNotifications() {
        while (medicalDose.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e)  {
                Thread.currentThread().interrupt();
                logger.info("Thread interrupted");
            }
        }
        notifyAll();
    }


    /**
     * show the notification using logger
     * @param medicalDose
     * @param alarmpriority
     */
    private  synchronized void showNotification(MedicalDose medicalDose , Alarmpriority alarmpriority) {
        while (!medicalDose.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException e)  {
                Thread.currentThread().interrupt();
                logger.info("Thread interrupted");
            }
        }
       this.medicalDose = medicalDose;
        this.alarmpriority=alarmpriority;
        notifyAll();

    }

    @Override
    public Notification getResetNotification() {
        return null;
    }

    @Override
    public int getNextDoseId() {
        return 0;
    }

    @Override
    public Notification getNextDoseNotification() {
        return null;
    }
}

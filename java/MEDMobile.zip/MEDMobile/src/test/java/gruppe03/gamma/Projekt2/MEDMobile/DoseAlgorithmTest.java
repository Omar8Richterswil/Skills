package gruppe03.gamma.Projekt2.MEDMobile;

import gruppe03.gamma.Projekt2.MEDMobile.Model.Medicament;
import gruppe03.gamma.Projekt2.MEDMobile.Model.MedicamentInfo;
import gruppe03.gamma.Projekt2.MEDMobile.Model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DoseAlgorithmTest {
    DoseAlgorithm doseAlgorithm;
    @Mock
    User userMock;

    @BeforeEach
    void setUp() {
        doseAlgorithm= new DoseAlgorithm();
        MockitoAnnotations.initMocks(this);
        }

    @Test
    void BMInormalValues() {
        when(userMock.getHeightCM()).thenReturn(180);
        when(userMock.getWeightKg()).thenReturn(80);
        assertEquals(24.69,doseAlgorithm.BMI(userMock) );
        verify(userMock, times(1)).getWeightKg();
        verify(userMock, times(1)).getHeightCM();
    }
    @Test
    void BMInegativeValues() {
        when(userMock.getHeightCM()).thenReturn(180);
        when(userMock.getWeightKg()).thenReturn(-80);
        assertEquals(-24.69,doseAlgorithm.BMI(userMock) );
        verify(userMock, times(1)).getWeightKg();
        verify(userMock, times(1)).getHeightCM();
    }


    @Test
    void BMRMale() {
        when(userMock.getGender()).thenReturn("m");
        when(userMock.getHeightCM()).thenReturn(180);
        when(userMock.getWeightKg()).thenReturn(80);
        when(userMock.getHeightCM()).thenReturn(180);
        when(userMock.getAge()).thenReturn(30);
        assertEquals(1858.0,doseAlgorithm.BMR(userMock));
        verify(userMock, times(1)).getWeightKg();
        verify(userMock, times(1)).getHeightCM();
        verify(userMock, times(1)).getAge();
    }
    @Test
    void BMRFemale() {
        when(userMock.getGender()).thenReturn("f");
        when(userMock.getHeightCM()).thenReturn(180);
        when(userMock.getWeightKg()).thenReturn(80);
        when(userMock.getAge()).thenReturn(30);
        assertEquals(1606.0,doseAlgorithm.BMR(userMock));
        verify(userMock, times(1)).getWeightKg();
        verify(userMock, times(1)).getHeightCM();
        verify(userMock, times(1)).getAge();
    }

    @Test
    void idealWeightMale() {
        when(userMock.getGender()).thenReturn("m");
        when(userMock.getHeightCM()).thenReturn(180);
        assertEquals(75.2,doseAlgorithm.idealWeight(userMock));
        verify(userMock, times(1)).getHeightCM();
    }

    @Test
    void idealWeightFemale() {
        when(userMock.getGender()).thenReturn("f");
        when(userMock.getHeightCM()).thenReturn(180);
        assertEquals(70.7,doseAlgorithm.idealWeight(userMock));
        verify(userMock, times(1)).getHeightCM();
    }

}
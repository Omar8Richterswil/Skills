package gruppe03.gamma.Projekt2.MEDMobile;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Set;
import java.sql.Date;

import gruppe03.gamma.Projekt2.MEDMobile.Model.Medicament;
import gruppe03.gamma.Projekt2.MEDMobile.Model.Patient;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class PatientTest {
	
	Patient patient;
	int age;
	String testInsuranceNumber;
	Medicament medicament;
	
	
	@BeforeEach
	public void setUp(){
		
		patient = new Patient("firstname", "lastname", age, false, testInsuranceNumber, 50, 150, false, "username", "password");
		medicament = new Medicament("testMedi",MedicalUtil.mediType.CREAM, MedicalUtil.amountType.ML,100, AlarmFrequency.Dailly);
		
	}
	
	
	@Test
	public void testAddMedicament(){
		assertTrue(patient.getMedicamentInventory().isEmpty());
		assertFalse(patient.getMedicamentInventory().containsKey(medicament));
		patient.addMedicament(medicament,100,AlarmFrequency.Dailly);
		assertEquals(100, patient.getMedicamentAmountFromMap(medicament));
	}
	
	@Test
	public void testMedicamentAmountAndAlarmFrequency(){
		testAddMedicament();
		assertEquals(AlarmFrequency.Dailly, patient.getMedicamentAlarmFrequency(medicament));
		assertEquals(AlarmFrequency.Dailly, patient.getAlarmFrequencyFromMap(medicament));
		assertNotEquals(1000, patient.getMedicamentAmount(medicament));
	}
	
	@Test
	public void testTakeMedicament(){
		testAddMedicament();
		patient.takeAMedicament(medicament);
		assertEquals(99, patient.getMedicamentAmount(medicament));
		patient.takeMedicaments(medicament,50);
		assertEquals(49, patient.getMedicamentAmount(medicament));
		
	}
	
	
	@Test
	public void testFinishedMedicament(){
		testAddMedicament();
		patient.takeMedicaments(medicament,100);
		assertTrue(patient.finishedMedicament(medicament));
	}

}

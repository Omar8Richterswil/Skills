package gruppe03.gamma.Projekt2.MEDMobile;

import gruppe03.gamma.Projekt2.MEDMobile.Model.Medicament;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

class TodayDoseTest {
	
	@Mock
	private Medicament mockDrug;
	@Mock
	private TakeDose mockTakeDose;
	
	private TodayDose todayDoseUnderTest;
	
	@BeforeEach
	void setUp() {
		initMocks(this);
		todayDoseUnderTest = new TodayDose(1, mockDrug, LocalTime.of(12, 0, 0), mockTakeDose, 0);
	}
	
	@Test
	void testGetDrugName() {
		// Setup
		when(mockDrug.getName()).thenReturn("Dafalgan");
		
		// Run the test
		final String result = todayDoseUnderTest.getDrugName();
		
		// Verify the results
		assertEquals("Dafalgan", result);
	}
	
	@Test
	void testWasTaken() {
		// Setup
		when(mockTakeDose.isTaken()).thenReturn(false);
		
		// Run the test
		final boolean result = todayDoseUnderTest.wasTaken();
		
		// Verify the results
		assertFalse(result);
	}
	
	
}

package gruppe03.gamma.Projekt2.MEDMobile;

import gruppe03.gamma.Projekt2.MEDMobile.Model.Medicament;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

class MedicalDoseTest {
	
	@Mock
	private Medicament mockMedicament;
	
	private MedicalDose medicalDoseUnderTest;
	
	@BeforeEach
	void setUp() {
		initMocks(this);
		medicalDoseUnderTest = new MedicalDose(mockMedicament);
	}
	
	@Test
	void testMedicalDoseAlgorithm() {
		// Setup
		final Medicament medicament = new Medicament("Dafalgan", MedicalUtil.mediType.TABLET, MedicalUtil.amountType.MG, 0, AlarmFrequency.ThreeTimeinDay);
		
		// Run the test
		final int result = medicalDoseUnderTest.medicalDoseAlgorithm(medicament);
		
		// Verify the results
		assertEquals(0, result);
	}
	
	@Test
	void testToString() {
		// Setup
		when(mockMedicament.getName()).thenReturn("Dafalgan");
		when(mockMedicament.getDose()).thenReturn(2);
		
		// Run the test
		final String result = medicalDoseUnderTest.toString();
		
		// Verify the results
		assertEquals("Dafalgan Dose 2", result);
	}
	
	@Test
	void testIsEmpty() {
		// Setup
		when(mockMedicament.getDose()).thenReturn(0);
		
		// Run the test
		final boolean result = medicalDoseUnderTest.isEmpty();
		
		// Verify the results
		assertTrue(result);
	}
}

